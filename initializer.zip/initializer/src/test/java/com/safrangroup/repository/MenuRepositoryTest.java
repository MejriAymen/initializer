/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.repository;

import com.safrangroup.model.Menu;
import com.safrangroup.utils.constant.NumberConstant;
import static org.assertj.core.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

/**
 * @author L60018794
 */
@DataJpaTest
public class MenuRepositoryTest {

    @Autowired
    MenuRepository underTest;

    @AfterEach
    void tearDown() {
        underTest.deleteAll();
    }

    @Test
    void shouldSaveMenu() {
        Menu menu = underTest.save(new Menu("TEST ONE", "TEST ONE"));
        assertThat(menu).isNotNull();
        underTest.findAll();
        menu = underTest.findByCode("TEST ONE");
        assertThat(menu).isNotNull();
        assertThat(menu.getLibelle()).startsWith("TEST").endsWith("ONE").isEqualToIgnoringWhitespace("TESTONE");
    }

    @Test
    void shouldNotFindMenuByCode() {
        Menu menu = underTest.findByCode(NumberConstant.ZERO.toString());
        assertThat(menu).isNull();
    }
}
