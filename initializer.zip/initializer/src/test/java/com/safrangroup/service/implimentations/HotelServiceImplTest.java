/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.DTO.HotelDto;
import com.safrangroup.model.Hotel;
import com.safrangroup.repository.HotelRepository;
import com.safrangroup.service.interfaces.HotelService;
import static org.assertj.core.api.Assertions.*;
import org.hamcrest.core.Is;
import static org.junit.Assert.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 *
 * @author L60018794
 */
@SpringBootTest
//@Transactional
public class HotelServiceImplTest {

    @Autowired
    HotelService hotelService;
    @Autowired
    HotelRepository hotelRepository;

    /**
     * Test of add method, of class HotelServiceImpl.
     */
    @Test
    public void testAdd() {
        Hotel beforeSave = new Hotel("BrazaVille");
        Hotel afterSave = HotelDto.fromDto(hotelService.add(HotelDto.toDto(beforeSave)));
        assertThat(afterSave.getLibelle(), Is.is(beforeSave.getLibelle()));
        HotelDto hotelDto = HotelDto.builder().build();
        assertThatThrownBy(() -> {
            hotelService.add(hotelDto);
        }).hasMessage("Hotel n'est pas valide");
    }

    /**
     * Test of update method, of class HotelServiceImpl.
     */
    @Test
    public void testUpdate() {
        HotelDto hotelDtoBefore = hotelService.findById(1);
        hotelDtoBefore.setLibelle("OH LALA");
        HotelDto hotelDtoAfter = hotelService.update(hotelDtoBefore);
        assertThat(hotelDtoAfter.getLibelle()).contains("OH");

        assertThatThrownBy(() -> {
            hotelService.findById(221);
        }).hasMessage("Hotel non trouvée");
    }

//    /**
//     * Test of delete method, of class HotelServiceImpl.
//     */
//    @Test
//    public void testDelete() {
//        HotelDto hotelDtoBeforeDelete= hotelService.findById(1);
//        hotelService.delete(hotelDtoBeforeDelete.getId());
//           HotelDto hotelDtoAfterDelete= hotelService.findById(1);
//        assertFalse(hotelDtoAfterDelete.getVisible());
//    }
    /**
     * Test of findAll method, of class HotelServiceImpl.
     */
    @Test
    public void testFindAll() {
        assertTrue(hotelRepository.findMaxId() == hotelService.findAll().size());
    }

    /**
     * Test of findById method, of class HotelServiceImpl.
     */
    @Test
    public void testFindById() {
        assertThatThrownBy(() -> {
            assertTrue(hotelService.findById(125) == null);
        }).hasMessage("Hotel non trouvée");
    }

}
