/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.interfaces;

import com.safrangroup.DTO.HotelDto;
import com.safrangroup.model.Hotel;
import java.util.List;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.Assert.*;
import static org.assertj.core.api.Assertions.*;

/**
 *
 * @author L60018794
 */
public class HotelServiceTest {

    @Mock
    HotelService hotelService;

    public HotelServiceTest() {
    }

    @BeforeEach
    public void getResources() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void canAddHotel() {
        Hotel hotel = new Hotel("PALMA");
        Hotel hotel1 = new Hotel("PALMA BEACH");
        when(hotelService.add(HotelDto.toDto(hotel))).thenReturn(HotelDto.toDto(hotel1));
    }

    @Test
    void ensureSpyForListHotelsWorks() {
        List<HotelDto> hotels = (List<HotelDto>) hotelService.findAll();
        List<HotelDto> spyOnHotels = spy(hotels);
        when(spyOnHotels.size()).thenReturn(4);
        final Integer result = hotelService.findAll().size();
        assertEquals(4, spyOnHotels.size());
//        assertThat(result).isEqualTo(4);
    }
}
