/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.DTO.CircuitDto;
import com.safrangroup.DTO.HotelDto;
import com.safrangroup.DTO.SocieteJuridiqueDto;
import com.safrangroup.DTO.UtilisateurDto;
import com.safrangroup.DTO.VisiteFournisseurInternationalDto;
import com.safrangroup.DTO.VisiteFournisseurNationalDto;
import com.safrangroup.DTO.VisiteVisiteurAuditeurDto;
import com.safrangroup.DTO.VisiteVisiteurClientDto;
import com.safrangroup.DTO.VisiteVisiteurEcoleDto;
import com.safrangroup.DTO.VisiteVisiteurFormateurDto;
import com.safrangroup.DTO.VisiteVisiteurGroupeDto;
import com.safrangroup.DTO.VisiteVisiteurPrestataireDto;
import com.safrangroup.exception.exceptiongeneric.EntityNotFondExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.ExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.Circuit;
import com.safrangroup.model.FournisseurInterNational;
import com.safrangroup.model.FournisseurNational;
import com.safrangroup.model.Hotel;
import com.safrangroup.model.SocieteExterne;
import com.safrangroup.model.Utilisateur;
import com.safrangroup.model.ValeursParametre;
import com.safrangroup.model.VisiteurAuditeur;
import com.safrangroup.model.VisiteurClient;
import com.safrangroup.model.VisiteurEcole;
import com.safrangroup.model.VisiteurFormateur;
import com.safrangroup.model.VisiteurGroupe;
import com.safrangroup.model.VisiteurPrestataire;
import com.safrangroup.repository.RoleGlobalRepository;
import com.safrangroup.repository.UtilisateurRepository;
import com.safrangroup.repository.ValeursParametreRepository;
import com.safrangroup.repository.VisiteRepository;
import com.safrangroup.service.interfaces.HotelService;
import com.safrangroup.service.interfaces.PorteuseMenuRoleService;
import com.safrangroup.service.interfaces.RoleGlobalService;
import com.safrangroup.service.interfaces.SocieteExterneService;
import com.safrangroup.service.interfaces.UserService;
import com.safrangroup.service.interfaces.VisiteService;
import com.safrangroup.utils.constant.RoleConstants;
import com.safrangroup.utils.constant.visitetestconstant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import static org.assertj.core.api.Assertions.*;
import org.hamcrest.core.Is;
import static org.junit.Assert.*;
import org.junit.internal.runners.JUnit4ClassRunner;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author L60018794
 */
/*
Mode base réelle
 */
@RunWith(JUnit4ClassRunner.class)
@SpringBootTest
//@Transactional
@TestInstance(Lifecycle.PER_CLASS)
/*
Mode 2 base
 */
//@DataJpaTest
public class VisiteImplTest {

    @Autowired
    VisiteRepository repository;
    @Autowired
    VisiteService visiteService;
    @Autowired
    ValeursParametreRepository valeursParametreRepository;
    @Autowired
    UtilisateurRepository utilisateurRepository;
    @Autowired
    SocieteExterneService societeExterneService;
    @Autowired
    HotelService hotelService;
    @Autowired
    UserService userService;
    @Autowired
    PorteuseMenuRoleService porteuseMenuRoleService;
    @Autowired
    RoleGlobalService roleGlobalService;
    @Autowired
    RoleGlobalRepository roleGlobalRepository;

    @BeforeAll
    public void testRun() {
        hotelService.renfrocementBaseHotel();
        roleGlobalService.addRolesControleAcces();
        porteuseMenuRoleService.generateAllPorteuseMenuRole();
        userService.createUserAdminDefault();
        societeExterneService.add(new SocieteExterne("TOP NET", "CENTRE URBAIN NORD", "98652585", Boolean.TRUE));
        valeursParametreRepository.save(new ValeursParametre("SOC1"));
        valeursParametreRepository.save(new ValeursParametre("SOC2"));
        valeursParametreRepository.save(new ValeursParametre("SOC3"));
        assertFalse(hotelService.findAll().isEmpty());
        assertFalse(roleGlobalService.findAll().isEmpty());
        assertFalse(porteuseMenuRoleService.findAll().isEmpty());
        assertFalse(userService.findUsersByRole(roleGlobalRepository.findByCode(RoleConstants.DIRECTEUR_GENERAL).getId()).isEmpty());
        assertFalse(societeExterneService.findAll().isEmpty());
        assertFalse(valeursParametreRepository.findAll().isEmpty());
    }

//    @AfterAll
//    public void shouldFindVisitesDatePasserWithSuccess() {
//        Date date = new Date();
//        List<Visite> visites = visiteService.findByDate(date);
//        assertTrue("OK", !visites.isEmpty());
//        assertThat(visites.size(), Is.is(visiteService.idLastVisite()));
//        assertThat(visites).filteredOn(visite -> visite.getIntitule().contains("should")).extracting(visite -> visite.getId()).contains(1, 4, 5, 6);
//    }
    @Test
    @Order(1)
    public final void shouldAddSocieteExterne() {
        SocieteExterne beforeSave = new SocieteExterne("Tunisie télécom", "adresse", "98652385", Boolean.TRUE);
        SocieteExterne afterSave = societeExterneService.add(beforeSave);
        assertThat(afterSave).isNotNull();
        assertThat(afterSave.getLibelle(), Is.isA(String.class));
        assertThat(afterSave.getAdresse(), Is.is(beforeSave.getAdresse()));
        assertThat(afterSave.getLibelle()).isEqualTo("Tunisie télécom");
        assertThat(afterSave.getAdresse()).isNotEmpty();
        assertThat(afterSave.getLibelle()).isEqualToIgnoringCase("tunisie télécom");
        assertThat(afterSave.getLibelle()).startsWith("Tunisie").endsWith("om").isEqualToIgnoringWhitespace("Tunisietélécom");
    }

    @Test
    @Order(2)
    public final void shouldThrowsExceptions() {
        /*
        You can do it this way
         */
        assertThatThrownBy(() -> {
            throw new ExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }).hasMessage(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION.toString());
        /*
        Or this way 
         */
        Throwable throwable = catchThrowable(() -> {
            throw new EntityNotFondExceptionCatcher("Recherche erronée", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        });
        assertThat(throwable).hasMessageContaining("Recherche erronée");
        /*
        Exemple
         */

        assertThatThrownBy(() -> {
            hotelService.findById(120);
        }).hasMessage("Hotel non trouvée");

        Throwable throwabletest = catchThrowable(() -> {
            hotelService.findById(120);
        });
        assertThat(throwabletest).hasMessageContaining("Hotel non trouvée");
    }

    @Test
    @Order(3)
    public final void shouldAddRuWithoutChangingObject() {
        ValeursParametre beforeSave = new ValeursParametre("ZTE");
        ValeursParametre afterSave = valeursParametreRepository.save(beforeSave);
        assertSame(afterSave, beforeSave);
        beforeSave = new ValeursParametre("CST");
        afterSave = valeursParametreRepository.save(beforeSave);
        assertSame(afterSave, beforeSave);
        beforeSave = new ValeursParametre("SFT");
        afterSave = valeursParametreRepository.save(beforeSave);
        assertSame(afterSave, beforeSave);
    }

    @Test
    @Order(4)
    public final void shouldThrowEntityNotFoundExceptions2() {
        EntityNotFondExceptionCatcher expectedExceptions = assertThrows(EntityNotFondExceptionCatcher.class, () -> hotelService.findById(1112));;
        assertEquals(ErrorCodes.HOTEL_Not_Found, expectedExceptions.getErrorCodes());
        assertThat(expectedExceptions.getMessage()).isEqualTo("Hotel non trouvée");
    }

    /*
    Test Visite Internationale
     */
    @Test
    @Order(5)
    public final void shouldSaveVisiteVisiteurGroupeWithSuccess() {
        List<VisiteurGroupe> visiteursGroupes = new ArrayList<>();
        SocieteExterne societeExterne = societeExterneService.findById(1);
        visiteursGroupes.add(new VisiteurGroupe(visitetestconstant.NUM_PASSPORT, visitetestconstant.NOM1, visitetestconstant.PRENOM1, visitetestconstant.FONCTION1, visitetestconstant.CIN, visitetestconstant.NUM_TELEPHONE, visitetestconstant.NUM_VIS_A_VIS, 90, visitetestconstant.CONTACT_URGENCE, "photo.png", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        visiteursGroupes.add(new VisiteurGroupe(visitetestconstant.NUM_PASSPORT, visitetestconstant.NOM2, visitetestconstant.PRENOM2, visitetestconstant.FONCTION2, visitetestconstant.CIN, visitetestconstant.NUM_TELEPHONE, visitetestconstant.NUM_VIS_A_VIS, 90, visitetestconstant.CONTACT_URGENCE, "photo.png", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        List<Circuit> circuits = new ArrayList<>();
        ValeursParametre ru1 = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru2 = valeursParametreRepository.findById(2).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru3 = valeursParametreRepository.findById(3).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru1));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru2));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru3));
        Hotel hotel = HotelDto.fromDto(hotelService.findById(1));
        Utilisateur demandeur = (Utilisateur) utilisateurRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Demandeur NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre sociteJuridique = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Societe juridique NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        SocieteJuridiqueDto societeJuridiqueDto = SocieteJuridiqueDto.toDto(sociteJuridique);
        UtilisateurDto utilisateurDto = UtilisateurDto.toDto(demandeur);
        List<CircuitDto> circuitDtos = new ArrayList<>();
        circuits.forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        HotelDto hotelDto = HotelDto.toDto(hotel);
        VisiteVisiteurGroupeDto expResult = new VisiteVisiteurGroupeDto(visiteursGroupes, "666", "888", LocalDateTime.now(), LocalDateTime.now(), LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, hotelDto, 50, 50, "shouldSaveVisiteVisiteurGroupeWithSuccess", "Mission", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuitDtos, societeJuridiqueDto, utilisateurDto);
        Object result = visiteService.save(expResult);
        assertNotNull("OK", ((VisiteVisiteurGroupeDto) result).getId()
        );
    }

    @Test
    @Order(6)
    public final void shouldSaveVisiteVisiteurAuditeurWithSuccess() {
        List<VisiteurAuditeur> visiteurAuditeurs = new ArrayList<>();
        SocieteExterne societeExterne = societeExterneService.findById(1);
        visiteurAuditeurs.add(new VisiteurAuditeur(visitetestconstant.NUM_PASSPORT, visitetestconstant.NOM1, visitetestconstant.PRENOM1, visitetestconstant.FONCTION1, visitetestconstant.CIN, visitetestconstant.NUM_TELEPHONE, visitetestconstant.NUM_VIS_A_VIS, 90, visitetestconstant.CONTACT_URGENCE, "photo.png", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        visiteurAuditeurs.add(new VisiteurAuditeur(visitetestconstant.NUM_PASSPORT, visitetestconstant.NOM2, visitetestconstant.PRENOM2, visitetestconstant.FONCTION2, visitetestconstant.CIN, visitetestconstant.NUM_TELEPHONE, visitetestconstant.NUM_VIS_A_VIS, 90, visitetestconstant.CONTACT_URGENCE, "photo.png", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        List<Circuit> circuits = new ArrayList<>();
        ValeursParametre ru1 = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru2 = valeursParametreRepository.findById(2).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru3 = valeursParametreRepository.findById(3).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru1));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru2));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru3));
        Hotel hotel = HotelDto.fromDto(hotelService.findById(1));
        Utilisateur demandeur = (Utilisateur) utilisateurRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Demandeur NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre sociteJuridique = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Societe juridique NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        SocieteJuridiqueDto societeJuridiqueDto = SocieteJuridiqueDto.toDto(sociteJuridique);
        UtilisateurDto utilisateurDto = UtilisateurDto.toDto(demandeur);
        List<CircuitDto> circuitDtos = new ArrayList<>();
        circuits.forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        HotelDto hotelDto = HotelDto.toDto(hotel);
        VisiteVisiteurAuditeurDto expResult = new VisiteVisiteurAuditeurDto(visiteurAuditeurs, "666", "888", LocalDateTime.now(), LocalDateTime.now(), LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, hotelDto, 50, 50, "shouldSaveVisiteVisiteurAuditeurWithSuccess", "Mission", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuitDtos, societeJuridiqueDto, utilisateurDto);
        Object result = visiteService.save(expResult);
        assertNotNull("OK", ((VisiteVisiteurAuditeurDto) result).getId());
    }

    @Test
    @Order(7)
    public final void shouldSaveVisiteVisiteurClientWithSuccess() {
        List<VisiteurClient> visiteurClients = new ArrayList<>();
        SocieteExterne societeExterne = societeExterneService.findById(1);
        visiteurClients.add(new VisiteurClient(visitetestconstant.NUM_PASSPORT, visitetestconstant.NOM1, visitetestconstant.PRENOM1, visitetestconstant.FONCTION1, visitetestconstant.CIN, visitetestconstant.NUM_TELEPHONE, visitetestconstant.NUM_VIS_A_VIS, 90, visitetestconstant.CONTACT_URGENCE, "photo.png", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        visiteurClients.add(new VisiteurClient(visitetestconstant.NUM_PASSPORT, visitetestconstant.NOM2, visitetestconstant.PRENOM2, "RIngénieur", visitetestconstant.CIN, visitetestconstant.NUM_TELEPHONE, visitetestconstant.NUM_VIS_A_VIS, 90, visitetestconstant.CONTACT_URGENCE, "photo.png", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        List<Circuit> circuits = new ArrayList<>();
        ValeursParametre ru1 = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru2 = valeursParametreRepository.findById(2).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru3 = valeursParametreRepository.findById(3).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru1));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru2));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru3));
        Hotel hotel = HotelDto.fromDto(hotelService.findById(1));
        Utilisateur demandeur = (Utilisateur) utilisateurRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Demandeur NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre sociteJuridique = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Societe juridique NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        SocieteJuridiqueDto societeJuridiqueDto = SocieteJuridiqueDto.toDto(sociteJuridique);
        UtilisateurDto utilisateurDto = UtilisateurDto.toDto(demandeur);
        List<CircuitDto> circuitDtos = new ArrayList<>();
        circuits.forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        HotelDto hotelDto = HotelDto.toDto(hotel);
        VisiteVisiteurClientDto expResult = new VisiteVisiteurClientDto(visiteurClients, "666", "888", LocalDateTime.now(), LocalDateTime.now(), LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, hotelDto, 50, 50, "shouldSaveVisiteVisiteurClientWithSuccess", "Mission", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuitDtos, societeJuridiqueDto, utilisateurDto);
        Object result = visiteService.save(expResult);
        assertNotNull("OK", ((VisiteVisiteurClientDto) result).getId());
    }

    @Test
    @Order(8)
    public final void shouldSaveVisiteVisiteurPrestataireWithSuccess() {
        List<VisiteurPrestataire> visiteurPrestataires = new ArrayList<>();
        SocieteExterne societeExterne = societeExterneService.findById(1);
        visiteurPrestataires.add(new VisiteurPrestataire(visitetestconstant.NUM_PASSPORT, visitetestconstant.NOM1, visitetestconstant.PRENOM1, visitetestconstant.FONCTION1, visitetestconstant.CIN, visitetestconstant.NUM_TELEPHONE, visitetestconstant.NUM_VIS_A_VIS, 90, visitetestconstant.CONTACT_URGENCE, "photo.png", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        visiteurPrestataires.add(new VisiteurPrestataire(visitetestconstant.NUM_PASSPORT, visitetestconstant.NOM2, visitetestconstant.PRENOM2, "RIngénieur", visitetestconstant.CIN, visitetestconstant.NUM_TELEPHONE, visitetestconstant.NUM_VIS_A_VIS, 90, visitetestconstant.CONTACT_URGENCE, "photo.png", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        List<Circuit> circuits = new ArrayList<>();
        ValeursParametre ru1 = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru2 = valeursParametreRepository.findById(2).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru3 = valeursParametreRepository.findById(3).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru1));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru2));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru3));
        Hotel hotel = HotelDto.fromDto(hotelService.findById(1));
        Utilisateur demandeur = (Utilisateur) utilisateurRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Demandeur NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre sociteJuridique = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Societe juridique NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        SocieteJuridiqueDto societeJuridiqueDto = SocieteJuridiqueDto.toDto(sociteJuridique);
        UtilisateurDto utilisateurDto = UtilisateurDto.toDto(demandeur);
        List<CircuitDto> circuitDtos = new ArrayList<>();
        circuits.forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        HotelDto hotelDto = HotelDto.toDto(hotel);
        VisiteVisiteurPrestataireDto expResult = new VisiteVisiteurPrestataireDto(visiteurPrestataires, "666", "888", LocalDateTime.now(), LocalDateTime.now(), LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, hotelDto, 50, 50, "shouldSaveVisiteVisiteurPrestataireWithSuccess", "Mission", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuitDtos, societeJuridiqueDto, utilisateurDto);
        Object result = visiteService.save(expResult);
        assertNotNull("OK", ((VisiteVisiteurPrestataireDto) result).getId());
    }

    @Test
    @Order(9)
    public final void shouldSaveVisiteFournisseurInternationalWithSuccess() {
        List<FournisseurInterNational> fournisseurInterNationals = new ArrayList<>();
        SocieteExterne societeExterne = societeExterneService.findById(1);
        fournisseurInterNationals.add(new FournisseurInterNational("numPasseport", "mail", "nom", "prenom", "fonction", "cin", "numTelephone", "numVisAVis", 50, "contactUrgence", "photo", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        fournisseurInterNationals.add(new FournisseurInterNational("numPasseport 1", "mail1", "nom1", "prenom1", "fonction1", "cin1", "numTelephone1", "numVisAVis", 50, "contactUrgence1", "photo", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        List<Circuit> circuits = new ArrayList<>();
        ValeursParametre ru1 = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru2 = valeursParametreRepository.findById(2).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru3 = valeursParametreRepository.findById(3).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru1));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru2));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru3));
        Hotel hotel = HotelDto.fromDto(hotelService.findById(1));
        Utilisateur demandeur = (Utilisateur) utilisateurRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Demandeur NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre sociteJuridique = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Societe juridique NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        SocieteJuridiqueDto societeJuridiqueDto = SocieteJuridiqueDto.toDto(sociteJuridique);
        UtilisateurDto utilisateurDto = UtilisateurDto.toDto(demandeur);
        List<CircuitDto> circuitDtos = new ArrayList<>();
        circuits.forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        HotelDto hotelDto = HotelDto.toDto(hotel);
        VisiteFournisseurInternationalDto expResult = new VisiteFournisseurInternationalDto(fournisseurInterNationals, "666", "888", LocalDateTime.now(), LocalDateTime.now(), LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, hotelDto, 50, 50, "shouldSaveVisiteFournisseurInternationalWithSuccess", "Mission", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuitDtos, societeJuridiqueDto, utilisateurDto);
        Object result = visiteService.save(expResult);
        assertNotNull("OK", ((VisiteFournisseurInternationalDto) result).getId());
    }

    /*
    Test Visite  nationale
     */
    @Test
    @Order(10)
    public final void shouldSaveVisiteEcoleWithSuccess() {
        List<VisiteurEcole> visiteurEcoles = new ArrayList<>();
        SocieteExterne societeExterne = societeExterneService.findById(1);
        visiteurEcoles.add(new VisiteurEcole("nom", "prenom", "fonction", "cin", "numTelephone", "numVisAVis", 10, "contactUrgence", "photo", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        visiteurEcoles.add(new VisiteurEcole("nom1", "prenom1", "fonction1", "cin1", "numTelephone1", "numVisAVis", 10, "contactUrgence", "photo", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        List<Circuit> circuits = new ArrayList<>();
        ValeursParametre ru1 = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru2 = valeursParametreRepository.findById(2).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru3 = valeursParametreRepository.findById(3).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru1));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru2));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru3));
        Hotel hotel = HotelDto.fromDto(hotelService.findById(1));
        Utilisateur demandeur = (Utilisateur) utilisateurRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Demandeur NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre sociteJuridique = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Societe juridique NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        SocieteJuridiqueDto societeJuridiqueDto = SocieteJuridiqueDto.toDto(sociteJuridique);
        UtilisateurDto utilisateurDto = UtilisateurDto.toDto(demandeur);
        List<CircuitDto> circuitDtos = new ArrayList<>();
        circuits.forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        HotelDto hotelDto = HotelDto.toDto(hotel);
        VisiteVisiteurEcoleDto expResult = new VisiteVisiteurEcoleDto(visiteurEcoles, 10, "shouldSaveVisiteEcoleWithSuccess", "objectif", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuitDtos, societeJuridiqueDto, utilisateurDto);
        Object result = visiteService.save(expResult);
//        assertEquals(expResult.getDateVisite(), ((VisiteVisiteurEcoleDto) result).getDateVisite());
        assertNotNull("OK", ((VisiteVisiteurEcoleDto) result).getId());
    }

    @Test
    @Order(11)
    public final void shouldSaveVisiteFormateurWithSuccess() {
        List<VisiteurFormateur> visiteurFormateurs = new ArrayList<>();
        SocieteExterne societeExterne = societeExterneService.findById(1);
        visiteurFormateurs.add(new VisiteurFormateur("nom", "prenom", "fonction", "cin", "numTelephone", "numVisAVis", 10, "contactUrgence", "photo", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        visiteurFormateurs.add(new VisiteurFormateur("nom1", "prenom1", "fonction1", "cin1", "numTelephone1", "numVisAVis", 10, "contactUrgence", "photo", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        List<Circuit> circuits = new ArrayList<>();
        ValeursParametre ru1 = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru2 = valeursParametreRepository.findById(2).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru3 = valeursParametreRepository.findById(3).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru1));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru2));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru3));
        Hotel hotel = HotelDto.fromDto(hotelService.findById(1));
        Utilisateur demandeur = (Utilisateur) utilisateurRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Demandeur NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre sociteJuridique = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Societe juridique NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        SocieteJuridiqueDto societeJuridiqueDto = SocieteJuridiqueDto.toDto(sociteJuridique);
        UtilisateurDto utilisateurDto = UtilisateurDto.toDto(demandeur);
        List<CircuitDto> circuitDtos = new ArrayList<>();
        circuits.forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        HotelDto hotelDto = HotelDto.toDto(hotel);
        VisiteVisiteurFormateurDto expResult = new VisiteVisiteurFormateurDto(visiteurFormateurs, 10, "shouldSaveVisiteFormateurWithSuccess", "objectif", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuitDtos, societeJuridiqueDto, utilisateurDto);
        Object result = visiteService.save(expResult);
        assertNotNull("OK", ((VisiteVisiteurFormateurDto) result).getId());
    }

    @Test
    @Order(12)
    public final void shouldSaveVisiteFournisseurNationalWithSuccess() {
        List<FournisseurNational> fournisseurNationals = new ArrayList<>();
        SocieteExterne societeExterne = societeExterneService.findById(1);
        fournisseurNationals.add(new FournisseurNational("mail", "nom", "prenom", "fonction", "cin", "numTelephone", "numVisAVis", 10, "contactUrgence", "photo", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        fournisseurNationals.add(new FournisseurNational("mail", "nom1", "prenom1", "fonction1", "cin1", "numTelephone1", "numVisAVis", 10, "contactUrgence", "photo", LocalDateTime.now(), LocalDateTime.now(), societeExterne));
        List<Circuit> circuits = new ArrayList<>();
        ValeursParametre ru1 = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru2 = valeursParametreRepository.findById(2).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre ru3 = valeursParametreRepository.findById(3).orElseThrow(() -> new EntityNotFondExceptionCatcher("RU NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru1));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru2));
        circuits.add(new Circuit(LocalDateTime.now(), LocalDateTime.now(), 1, 1, ru3));
        Hotel hotel = HotelDto.fromDto(hotelService.findById(1));
        Utilisateur demandeur = (Utilisateur) utilisateurRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Demandeur NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        ValeursParametre sociteJuridique = valeursParametreRepository.findById(1).orElseThrow(() -> new EntityNotFondExceptionCatcher("Societe juridique NOT FOUND", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        SocieteJuridiqueDto societeJuridiqueDto = SocieteJuridiqueDto.toDto(sociteJuridique);
        UtilisateurDto utilisateurDto = UtilisateurDto.toDto(demandeur);
        List<CircuitDto> circuitDtos = new ArrayList<>();
        circuits.forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        VisiteFournisseurNationalDto expResult = new VisiteFournisseurNationalDto(fournisseurNationals, 10, "shouldSaveVisiteFournisseurNationalWithSuccess", "objectif", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuitDtos, societeJuridiqueDto, utilisateurDto);
        Object result = visiteService.save(expResult);
        assertNotNull("OK", ((VisiteFournisseurNationalDto) result).getId());
    }

}
