/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.utils.mapper;

import static org.junit.Assert.*;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

/**
 * @author L60018794
 */
public class ObjectMapperDemoTest {

    /*
    Frontend ---JSON String---> Deserialization-----java Object--->  Backend
     */
    @Test
    @Order(1)
    void deserializationJsontoLaptopObjectTest() {
        assertTrue(ObjectMapperDemo.deserializationJsontoLaptopObject().toString().equals("Laptop(brand=ABC, model=XY1)"));
    }

    @Test
    @Order(2)
    void deserializationJsonStringArrayToLaptopArrayOfObjectsTest() {
        assertTrue(ObjectMapperDemo.deserializationJsonStringArrayToLaptopArrayOfObjects().length == 3);
    }

    @Test
    @Order(3)
    void deserializationJsonStringArrayToListOfLaptopObjectsTest() {
        assertTrue(ObjectMapperDemo.deserializationJsonStringArrayToListOfLaptopObjects().size() == 3);
    }

    @Test
    @Order(4)
    void deserializationJsonStringToAmapOfObjectsTest() {
        assertTrue(ObjectMapperDemo.deserializationJsonStringToAmapOfObjects().containsKey("brand") && ObjectMapperDemo.deserializationJsonStringToAmapOfObjects().containsKey("model"));
    }

    /*
    Reverse
    Frontend ---JSON String---> Serialization-----java Object------  Backend
     */
    @Test
    @Order(5)
    void serializeObjectToJsonTest() {
        assertTrue(ObjectMapperDemo.serializeObjectToJson().equals("[{\"brand\":\"brand\",\"model\":\"ABC\"},{\"brand\":\"brand\",\"model\":\"ABC\"}]"));
    }
}
