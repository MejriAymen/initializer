/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.exception.exceptiongeneric;

import com.safrangroup.exception.handler.ErrorCodes;
import static org.junit.Assert.*;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

/**
 *
 * @author L60018794
 */
@RunWith(JUnit4ClassRunner.class)
@SpringBootTest
public class ConstraintViolationExceptionCatcherTest {

    public ConstraintViolationExceptionCatcherTest() {
    }

    /**
     * Test of getErrorCodes method, of class
     * ConstraintViolationExceptionCatcher.
     */
    @Test
    public void testGetErrorCodes() {
        ConstraintViolationExceptionCatcher instance = new ConstraintViolationExceptionCatcher(ErrorCodes.getEnumByCode(2014));
        ErrorCodes result = instance.getErrorCodes();
        assertEquals(result, ErrorCodes.CONSTRAINT_VIOLATION_EXCEPTION);
    }

}
