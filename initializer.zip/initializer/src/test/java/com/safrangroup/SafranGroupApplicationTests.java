package com.safrangroup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafranGroupApplicationTests {

    @Test
    void contextLoads() {
    }

}
