package com.safrangroup.config;

public interface SecurityParams {

    public static final String JWT_HEADER_NAME = "Authorization";
    public static final String SECRET = "safran20222";
    public static final long EXPIRATION = 5 * 60 * 60 * 1000;
    public static final String HEADER_PREFIX = "Bearer ";

    public static final String DOMAIN_NAME = "corp.zodiac.lan";
    public static final String AD_URL = "ldap://corp.zodiac.lan/";
    public static final String USER_NAME = "BKPADMIN";
    public static final String PW_AUTH = "Z0di@cit";
    public static final String FRONT_CROSS_ORIGIN_URL = "http://localhost:4200/";
    public static final String FRONT_CROSS_ORIGIN_USER_URL = "*";

}
