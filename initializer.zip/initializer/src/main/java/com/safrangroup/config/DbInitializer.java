package com.safrangroup.config;

import com.safrangroup.service.interfaces.HotelService;
import com.safrangroup.service.interfaces.PorteuseMenuRoleService;
import com.safrangroup.service.interfaces.RoleGlobalService;
import com.safrangroup.service.interfaces.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.stereotype.Component;

@EnableWebSecurity
@Component
public class DbInitializer implements CommandLineRunner {

    @Autowired
    PorteuseMenuRoleService porteuseMenuRoleService;
    @Autowired
    RoleGlobalService roleGlobalService;
    @Autowired
    HotelService hotelService;
    @Autowired
    UserService userService;

    public DbInitializer() {
        super();
    }

    @Override
    public void run(String... args) throws Exception {
        hotelService.renfrocementBaseHotel();
        roleGlobalService.addRolesControleAcces();
        porteuseMenuRoleService.generateAllPorteuseMenuRole();
        userService.createUserAdminDefault();
    }
}
