/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.exception.exceptiongeneric.EntityNotFondExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.ParametresGeneraux;
import com.safrangroup.model.ValeursParametre;
import com.safrangroup.repository.ParametresGenerauxRepository;
import com.safrangroup.repository.ValeursParametreRepository;
import com.safrangroup.service.interfaces.ValeurParametreService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ala.Nabli
 */
@Service
public class ValeurParametreImpl implements ValeurParametreService {

    @Autowired
    ValeursParametreRepository valeursParametreRepository;
    @Autowired
    ParametresGenerauxRepository parametresGenerauxRepository;

    @Override
    public List<ValeursParametre> getValeursParametreByIdParametre(Integer idParametre) {
        ParametresGeneraux pg = parametresGenerauxRepository.findById(idParametre)
                .orElseThrow(() -> new EntityNotFondExceptionCatcher("Parametre generaux not found", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        List<ValeursParametre> valeursParametre = valeursParametreRepository.findValeursParametreByParametreGeneral(pg)
                .orElseThrow(() -> new EntityNotFondExceptionCatcher("valeur parametre not found", ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        return valeursParametre;
    }
}
