/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.dtos.ResponsePorteuseRoleMenuDTO;
import com.safrangroup.exception.exceptiongeneric.EntityNotFondExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.InvalidEntityExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.Menu;
import com.safrangroup.model.PorteuseMenuRole;
import com.safrangroup.model.RoleGlobal;
import com.safrangroup.repository.PorteuseMenuRoleRepository;
import com.safrangroup.repository.RoleGlobalRepository;
import com.safrangroup.service.interfaces.MenuService;
import com.safrangroup.service.interfaces.PorteuseMenuRoleService;
import com.safrangroup.utils.constant.MenuConstants;
import com.safrangroup.utils.constant.NumberConstant;
import com.safrangroup.utils.constant.RoleConstants;
import com.safrangroup.validator.PorteuseMenuRoleValidator;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

/**
 *
 * @author L258775
 */
@Service
public class PorteuseMenuRoleServiceImpl implements PorteuseMenuRoleService {

    @Autowired
    private PorteuseMenuRoleRepository entityRepository;
    @Autowired
    RoleGlobalRepository roleRepository;
    @Autowired
    MenuService menuService;

    @Override
    public PorteuseMenuRole add(PorteuseMenuRole entity) {
        List<String> errors = PorteuseMenuRoleValidator.validateAdd(entity);
        if (!errors.isEmpty()) {
            Logger.getLogger(PorteuseMenuRoleServiceImpl.class.getName()).log(Level.SEVERE, "PorteuseMenuRole n'est pas valide", entity);
            throw new InvalidEntityExceptionCatcher("PorteuseMenuRole n'est pas valide", ErrorCodes.PorteuseMenuRole_Not_Valid, errors);
        }

        return entityRepository.save(entity);

    }

    @Override
    public PorteuseMenuRole update(PorteuseMenuRole entity) {
        try {
            List<String> errors = PorteuseMenuRoleValidator.validateUpdate(entity);
            if (!errors.isEmpty()) {
                Logger.getLogger(PorteuseMenuRoleServiceImpl.class.getName()).log(Level.SEVERE, "PorteuseMenuRole n'est pas valide", entity);
                throw new InvalidEntityExceptionCatcher("PorteuseMenuRole n'est pas valide", ErrorCodes.PorteuseMenuRole_Not_Valid, errors);
            }
            PorteuseMenuRole entityEdit = entityRepository.findById(entity.getId()).orElseThrow(() -> new EntityNotFondExceptionCatcher());
            entity.setRole(entityEdit.getRole());
            entity.setMenu(entityEdit.getMenu());
            if (entityEdit == null) {
                throw new EntityNotFondExceptionCatcher("PorteuseMenuRole non trouvée", ErrorCodes.PorteuseMenuRole_Not_Found);
            } else {

                return entityRepository.save(entity);
            }
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

    @Override
    public void delete(Integer id) {
        if (findById(id) != null) {
            try {
                entityRepository.deleteById(id);
            } catch (DataIntegrityViolationException exception) {
                PorteuseMenuRole entity = findById(id);
                update(entity);
            }

        }
    }

    @Override
    public List<PorteuseMenuRole> findAll() {
        try {
            List<PorteuseMenuRole> entitys = entityRepository.findAll();
            if (entitys.isEmpty()) {
                throw new EntityNotFondExceptionCatcher("Pas de entity dans la base de donnée", ErrorCodes.Pas_De_PorteuseMenuRole_Dans_La_Base);
            } else {
                return entitys;
            }
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

    @Override
    public PorteuseMenuRole findById(Integer id) {
        try {
            if (id == null) {
                Logger.getLogger(PorteuseMenuRoleServiceImpl.class.getName()).log(Level.SEVERE, "PorteuseMenuRole ID NULL");
                return null;
            }
            Optional<PorteuseMenuRole> entity = entityRepository.findById(id);
            if (entity.equals(Optional.empty())) {
                throw new EntityNotFondExceptionCatcher("PorteuseMenuRole non trouvée", ErrorCodes.PorteuseMenuRole_Not_Found);
            }
            return Optional.of(entity.get()).orElseThrow(() -> new EntityNotFondExceptionCatcher("PorteuseMenuRole non trouvée", ErrorCodes.PorteuseMenuRole_Not_Found));
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

    @Override
    public List<PorteuseMenuRole> findByRole(RoleGlobal r) {
        try {
            if (r == null || r.getId() == null) {
                Logger.getLogger(PorteuseMenuRoleServiceImpl.class.getName()).log(Level.SEVERE, "PorteuseMenuRole ID NULL");
                return null;
            }
            List<PorteuseMenuRole> porteuseMenuRoles = entityRepository.findByRole(r);
            if (porteuseMenuRoles.isEmpty()) {
                throw new EntityNotFondExceptionCatcher("Vous n'avez pas encore des droits non trouvée", ErrorCodes.PorteuseMenuRole_Not_Found);
            }
            return porteuseMenuRoles;
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

    @Override
    public void generateAllPorteuseMenuRole() {

        menuService.generateAllMenu();

        final RoleGlobal DIRECTEUR_GENERAL = roleRepository.findByCode(RoleConstants.DIRECTEUR_GENERAL);
        final RoleGlobal COMPTABLE = roleRepository.findByCode(RoleConstants.COMPTABLE);
        final RoleGlobal CHARGER_DEPLACEMENT_PROFESSIONNEL = roleRepository.findByCode(RoleConstants.CHARGER_DEPLACEMENT_PROFESSIONNEL);
        final RoleGlobal CORRESPONDANT_RESTAURANT = roleRepository.findByCode(RoleConstants.CORRESPONDANT_RESTAURANT);
        final RoleGlobal CHARGER_SECURITE = roleRepository.findByCode(RoleConstants.CHARGER_SURETE);
        final RoleGlobal DIRECTEUR_RESSOURCES_HUMAINES = roleRepository.findByCode(RoleConstants.DIRECTEUR_RESSOURCES_HUMAINES);
        final RoleGlobal RESPONSABLE_RESSOURCES_HUMAINES = roleRepository.findByCode(RoleConstants.CORRESPONDANT_RESSOURCES_HUMAINES);
        final RoleGlobal RESPONSABLE_COMMUNICATION = roleRepository.findByCode(RoleConstants.RESPONSABLE_COMMUNICATION);
        final RoleGlobal CORRESPONDANT_SSE = roleRepository.findByCode(RoleConstants.CORRESPONDANT_SSE);
        final RoleGlobal FINANCE = roleRepository.findByCode(RoleConstants.FINANCE);

        final Menu NOUVELLE_DEMANDE = menuService.findByCode(MenuConstants.UN);
        final Menu MES_DEMANDES = menuService.findByCode(MenuConstants.DEUX);
        final Menu LISTE_DEMANDES = menuService.findByCode(MenuConstants.TROIS);
        final Menu DEMANDE_A_TRAITER = menuService.findByCode(MenuConstants.QUATRE);
        final Menu DEMANDE_A_CLOTURE = menuService.findByCode(MenuConstants.CINQUE);
        final Menu DEMANDE_A_VALIDER = menuService.findByCode(MenuConstants.SIX);
        final Menu LISTE_PASSEPORT = menuService.findByCode(MenuConstants.SEPT);
        final Menu STATISTIQUE = menuService.findByCode(MenuConstants.HUIT);
        final Menu ROLE_MENU = menuService.findByCode(MenuConstants.NEUF);
        final Menu NOUVELLE_VISITE = menuService.findByCode(MenuConstants.DIX);

        creationPorteuse(DIRECTEUR_GENERAL, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_GENERAL, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(COMPTABLE, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(COMPTABLE, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_DEPLACEMENT_PROFESSIONNEL, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(CORRESPONDANT_RESTAURANT, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_RESTAURANT, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(CHARGER_SECURITE, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CHARGER_SECURITE, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(DIRECTEUR_RESSOURCES_HUMAINES, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_RESSOURCES_HUMAINES, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(RESPONSABLE_COMMUNICATION, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(RESPONSABLE_COMMUNICATION, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(CORRESPONDANT_SSE, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(CORRESPONDANT_SSE, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        creationPorteuse(FINANCE, NOUVELLE_DEMANDE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, MES_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, LISTE_DEMANDES, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, DEMANDE_A_TRAITER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, DEMANDE_A_CLOTURE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, DEMANDE_A_VALIDER, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, LISTE_PASSEPORT, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, STATISTIQUE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, ROLE_MENU, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
        creationPorteuse(FINANCE, NOUVELLE_VISITE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
    }

    void creationPorteuse(RoleGlobal roleGlobal, Menu Menu_Utilisateur, Boolean generation, Boolean consultation, Boolean ajout, Boolean modification, Boolean suppression) {
        if (entityRepository.findByRoleAndMenu(roleGlobal, Menu_Utilisateur) == null) {
            add(new PorteuseMenuRole(roleGlobal, Menu_Utilisateur, generation, consultation, ajout, modification, suppression));
        }
    }

    @Override
    public List<ResponsePorteuseRoleMenuDTO> findAllPorteusesRolesMenus(Optional<Long> id
    ) {
        try {
            List<ResponsePorteuseRoleMenuDTO> porteuseRoleMenuDTOs = new ArrayList<>();
            List<Object[]> objects;
            if (id == null) {
                objects = entityRepository.findAllPorteusesRolesMenus();
            } else {
                objects = entityRepository.findAllPorteusesRolesMenus(id);
            }
            if (objects.isEmpty()) {
                throw new EntityNotFondExceptionCatcher("Pas de porteuse rôle menu trouvée", ErrorCodes.PorteuseMenuRole_Not_Found);
            } else {
                objects.forEach((record) -> {
                    String name = ((String) record[NumberConstant.ZERO]);
                    String code = ((String) record[NumberConstant.UN]);
                    String libelle = ((String) record[NumberConstant.DEUX]);
                    Boolean gen = ((Boolean) record[NumberConstant.TROIS]);
                    Boolean cons = ((Boolean) record[NumberConstant.QUATRE]);
                    Boolean aj = ((Boolean) record[NumberConstant.CINQUE]);
                    Boolean mod = ((Boolean) record[NumberConstant.SIX]);
                    Boolean supp = ((Boolean) record[NumberConstant.SEPT]);
                    porteuseRoleMenuDTOs.add(new ResponsePorteuseRoleMenuDTO(name, code, libelle, gen, cons, aj, mod, supp));
                });
            }

            return porteuseRoleMenuDTOs;
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

}
