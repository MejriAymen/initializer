/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.general;

import java.util.List;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author L258775
 * @param <T>
 */
public interface CRUDWithResponseService<T extends Object> {

    ResponseEntity<T> add(T entity);

    ResponseEntity<T> update(T entity);

    ResponseEntity delete(Integer id);

    T findById(Integer id);

    List<T> findAll();

}
