/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.interfaces;

import com.safrangroup.model.RoleGlobal;
import com.safrangroup.service.general.CRUDWithResponseService;

/**
 *
 * @author L258775
 */
public interface RoleGlobalService extends CRUDWithResponseService<RoleGlobal> {

    void addRolesControleAcces();

    RoleGlobal findByCode(String code);
}
