/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.interfaces;

import com.safrangroup.model.Utilisateur;
import java.util.List;

/**
 *
 * @author Ala.Nabli
 */
public interface UserService {

    List<Utilisateur> findUsersByRole(Integer id);

    public void sendMailConcernes();

    public void createUserAdminDefault();
}
