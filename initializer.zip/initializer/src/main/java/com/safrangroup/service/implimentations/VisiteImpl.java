/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.DTO.VisiteFournisseurInternationalDto;
import com.safrangroup.DTO.VisiteFournisseurNationalDto;
import com.safrangroup.DTO.VisiteVisiteurAuditeurDto;
import com.safrangroup.DTO.VisiteVisiteurClientDto;
import com.safrangroup.DTO.VisiteVisiteurEcoleDto;
import com.safrangroup.DTO.VisiteVisiteurFormateurDto;
import com.safrangroup.DTO.VisiteVisiteurGroupeDto;
import com.safrangroup.DTO.VisiteVisiteurPrestataireDto;
import com.safrangroup.exception.exceptiongeneric.ConstraintViolationExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.ExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.Circuit;
import com.safrangroup.model.VisiteInternationale;
import com.safrangroup.model.VisiteNationale;
import com.safrangroup.model.inhertance.Visite;
import com.safrangroup.repository.VisiteInternationaleRepository;
import com.safrangroup.repository.VisiteNationaleRepository;
import com.safrangroup.repository.VisiteRepository;
import com.safrangroup.service.interfaces.UserService;
import com.safrangroup.service.interfaces.VisiteService;
import com.safrangroup.utils.constant.MessagesConstants;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ala.Nabli
 */
@Service
public class VisiteImpl implements VisiteService {

    @Autowired
    VisiteRepository repository;
    @Autowired
    VisiteInternationaleRepository visiteInternationaleRepository;
    @Autowired
    VisiteNationaleRepository visiteNationaleRepository;
    LocalDateTime ldt;
    @Autowired
    UserService userService;

    public VisiteImpl() {
    }

    @Override
    public Object save(Object dto) {
        Object visite = this.handelSave(dto);
        if (visite != null) {
            userService.sendMailConcernes();
            return visite;
        } else {
            return null;
        }
    }

    public Object handelSave(Object dto) {
        try {
            VisiteInternationale visiteInternationale;
            VisiteNationale visiteNationale;

            if (dto instanceof VisiteVisiteurGroupeDto) {

                visiteInternationale = VisiteVisiteurGroupeDto.fromDto((VisiteVisiteurGroupeDto) dto);
                visiteInternationale.setCircuits(verifierCircuit(visiteInternationale.getDateVisite(), visiteInternationale.getCircuits()));
                return VisiteVisiteurGroupeDto.toDto(visiteInternationaleRepository.save(visiteInternationale));
            } else if (dto instanceof VisiteVisiteurAuditeurDto) {
                visiteInternationale = VisiteVisiteurAuditeurDto.fromDto((VisiteVisiteurAuditeurDto) dto);
                visiteInternationale.setCircuits(verifierCircuit(visiteInternationale.getDateVisite(), visiteInternationale.getCircuits()));
                return VisiteVisiteurAuditeurDto.toDto(visiteInternationaleRepository.save(visiteInternationale));
            } else if (dto instanceof VisiteVisiteurPrestataireDto) {
                visiteInternationale = VisiteVisiteurPrestataireDto.fromDto((VisiteVisiteurPrestataireDto) dto);
                visiteInternationale.setCircuits(verifierCircuit(visiteInternationale.getDateVisite(), visiteInternationale.getCircuits()));
                return VisiteVisiteurPrestataireDto.toDto(visiteInternationaleRepository.save(visiteInternationale));
            } else if (dto instanceof VisiteVisiteurClientDto) {
                visiteInternationale = VisiteVisiteurClientDto.fromDto((VisiteVisiteurClientDto) dto);
                visiteInternationale.setCircuits(verifierCircuit(visiteInternationale.getDateVisite(), visiteInternationale.getCircuits()));
                return VisiteVisiteurClientDto.toDto(visiteInternationaleRepository.save(visiteInternationale));
            } else if (dto instanceof VisiteFournisseurInternationalDto) {
                visiteInternationale = VisiteFournisseurInternationalDto.fromDto((VisiteFournisseurInternationalDto) dto);
                visiteInternationale.setCircuits(verifierCircuit(visiteInternationale.getDateVisite(), visiteInternationale.getCircuits()));
                return VisiteFournisseurInternationalDto.toDto(visiteInternationaleRepository.save(visiteInternationale));
            } else if (dto instanceof VisiteVisiteurEcoleDto) {
                visiteNationale = VisiteVisiteurEcoleDto.fromDto((VisiteVisiteurEcoleDto) dto);
                visiteNationale.setCircuits(verifierCircuit(visiteNationale.getDateVisite(), visiteNationale.getCircuits()));
                return VisiteVisiteurEcoleDto.toDto(visiteNationaleRepository.save(visiteNationale));
            } else if (dto instanceof VisiteVisiteurFormateurDto) {
                visiteNationale = VisiteVisiteurFormateurDto.fromDto((VisiteVisiteurFormateurDto) dto);
                visiteNationale.setCircuits(verifierCircuit(visiteNationale.getDateVisite(), visiteNationale.getCircuits()));
                return VisiteVisiteurFormateurDto.toDto(visiteNationaleRepository.save(visiteNationale));
            } else if (dto instanceof VisiteFournisseurNationalDto) {
                visiteNationale = VisiteFournisseurNationalDto.fromDto((VisiteFournisseurNationalDto) dto);
                visiteNationale.setCircuits(verifierCircuit(visiteNationale.getDateVisite(), visiteNationale.getCircuits()));
                return VisiteFournisseurNationalDto.toDto(visiteNationaleRepository.save(visiteNationale));
            } else {
                return null;
            }
        } catch (ConstraintViolationException e) {
            throw new ConstraintViolationExceptionCatcher(MessagesConstants.MESSAGE_EXCEPTION_ERROR_SAVE_VISITE, ErrorCodes.EXCEPTION);
        }

    }

    private List<Circuit> verifierCircuit(LocalDateTime dateTime, List<Circuit> circuits) {
        ldt = dateTime;
        Collections.sort(circuits);
        for (Circuit circuit : circuits) {
            circuit.setHeureDebut(ldt);
            ldt = ldt.plusMinutes(circuit.getDuree());
            circuit.setHeureFin(ldt);
        }
        return circuits;
    }

    @Override
    public List<Visite> findByDate(Date date) {
        try {
            return repository.findByDateWithoutTime(date);
        } catch (Exception e) {
            throw new ExceptionCatcher(ErrorCodes.ERROR_SCRIPT);
        }
    }

    @Override
    public Integer idLastVisite() {
        return repository.findMaxId();
    }

}
