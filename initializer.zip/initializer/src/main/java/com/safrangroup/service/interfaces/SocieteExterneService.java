/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.interfaces;

import com.safrangroup.model.SocieteExterne;
import com.safrangroup.service.general.CRUDService;

 

/**
 *
 * @author L258775
 */
public interface SocieteExterneService extends CRUDService<SocieteExterne> {
 
}
