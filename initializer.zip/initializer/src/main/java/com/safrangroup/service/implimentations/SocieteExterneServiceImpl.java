/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.exception.exceptiongeneric.EntityNotFondExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.InvalidEntityExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.SocieteExterne;
import com.safrangroup.repository.SocieteExterneRepository;
import com.safrangroup.service.interfaces.SocieteExterneService;
import com.safrangroup.validator.SocieteExterneValidator;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

/**
 *
 * @author L258775
 */
@Service
public class SocieteExterneServiceImpl implements SocieteExterneService {

    @Autowired
    private SocieteExterneRepository repository;

    @Override
    public SocieteExterne add(SocieteExterne entity) {
        List<String> errors = SocieteExterneValidator.validate(entity);
        if (!errors.isEmpty()) {
            throw new InvalidEntityExceptionCatcher("SocieteExterne n'est pas valide", ErrorCodes.HOTEL_Not_Valid, errors);
        }
        return repository.save(entity);

    }

    @Override
    public SocieteExterne update(SocieteExterne entity) {

        List<String> errors = SocieteExterneValidator.validate(entity);
        if (!errors.isEmpty()) {
            Logger.getLogger(SocieteExterneServiceImpl.class.getName()).log(Level.SEVERE, "SocieteExterne n'est pas valide", entity);
            throw new InvalidEntityExceptionCatcher("SocieteExterne n'est pas valide", ErrorCodes.HOTEL_Not_Valid, errors);
        }
        Optional<SocieteExterne> currentSocieteExterne = (Optional<SocieteExterne>) (Object) repository.findById(entity.getId());
        SocieteExterne entityEdit = currentSocieteExterne.orElse(null);
        if (entityEdit == null) {
            throw new EntityNotFondExceptionCatcher("SocieteExterne non trouvée", ErrorCodes.HOTEL_Not_Found);
        } else {
            return add(entity);
        }
    }

    @Override
    public void delete(Integer id) {
        if (findById(id) != null) {
            try {
                repository.deleteById(id);
            } catch (DataIntegrityViolationException exception) {
                SocieteExterne entity = findById(id);
                entity.setVisible(Boolean.FALSE);
                update(entity);
            }

        }
    }

    @Override
    public List<SocieteExterne> findAll() {
        List<SocieteExterne> entitys = (List<SocieteExterne>) (Object) repository.findAll();
        if (entitys.isEmpty()) {
            throw new EntityNotFondExceptionCatcher("Pas de entity dans la base de donnée", ErrorCodes.Pas_De_HOTEL_Dans_La_Base);
        } else {
            return entitys;
        }
    }

    @Override
    public SocieteExterne findById(Integer id) {
        if (id == null) {
            Logger.getLogger(SocieteExterneServiceImpl.class.getName()).log(Level.SEVERE, "SocieteExterne ID NULL");
            return null;
        }
        Optional<SocieteExterne> entity = (Optional<SocieteExterne>) (Object) repository.findById(id);
        if (entity.equals(Optional.empty())) {
            throw new EntityNotFondExceptionCatcher("SocieteExterne non trouvée", ErrorCodes.HOTEL_Not_Found);
        }
        return Optional.of(entity.get()).orElseThrow(() -> new EntityNotFondExceptionCatcher("SocieteExterne non trouvée", ErrorCodes.HOTEL_Not_Found));
    }

    

}
