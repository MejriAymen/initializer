/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service;

import com.safrangroup.model.Utilisateur;
import com.safrangroup.repository.UtilisateurRepository;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ala.Nabli
 */
@Service
public class JwtUserDetailsService implements UserDetailsService {

    final Integer DG_DGB = 1;
    final Integer COMPTABLE = 2;
    final Integer CHARGER_DEPLACEMENT = 3;
    final Integer RESPONSABLE = 4;
    final Integer UTILISATEUR = 5;
    final Integer COMPTABLE_RESPONSABLE = 6;
    final Integer CHARGER_DEPLACEMENT_RESPONSABLE = 7;
    final Integer CHARGER_SECURITE = 8;

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        Utilisateur user = utilisateurRepository.findUtilisateurByLogin(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
        if (user != null) {
            authorities.add(new SimpleGrantedAuthority(user.getRoleGlobal().getCode()));
            return new org.springframework.security.core.userdetails.User(user.getLogin(), "",
                    authorities);
        }
        return new org.springframework.security.core.userdetails.User(user.getLogin(), "",
                new ArrayList<>());
    }

    public Utilisateur save(Utilisateur user) {

        user.setActif(true);
        return utilisateurRepository.save(user);
    }

    public Integer getUserRole(Utilisateur user) {
        if (user.getType() != null && (user.getType() == 1 || user.getType() == 2)) {
            return DG_DGB;
        }
      
        List<Utilisateur> usersCheck = utilisateurRepository.findUtilisateurBySuperieur(user).orElse(null);

        if (usersCheck != null && !usersCheck.isEmpty()) {
            return RESPONSABLE;
        }
        return UTILISATEUR;
    }

}
