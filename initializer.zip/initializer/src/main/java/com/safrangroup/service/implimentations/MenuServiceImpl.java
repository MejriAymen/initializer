/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.exception.exceptiongeneric.EntityNotFondExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.InvalidEntityExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.Menu;
import com.safrangroup.repository.MenuRepository;
import com.safrangroup.service.interfaces.MenuService;
import com.safrangroup.utils.constant.MenuConstants;
import com.safrangroup.validator.MenuValidator;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

/**
 *
 * @author L258775
 */
@Service
public class MenuServiceImpl implements MenuService {

    @Autowired
    MenuRepository entityRepository;

    @Override
    public Menu add(Menu entity) {
        List<String> errors = MenuValidator.validate(entity);
        if (!errors.isEmpty()) {
            Logger.getLogger(MenuServiceImpl.class.getName()).log(Level.SEVERE, "Menu n'est pas valide", entity);
            throw new InvalidEntityExceptionCatcher("Menu n'est pas valide", ErrorCodes.Menu_Not_Valid, errors);
        }

        return entityRepository.save(entity);

    }

    @Override
    public Menu update(Menu entity) {
        try {
            List<String> errors = MenuValidator.validate(entity);
            if (!errors.isEmpty()) {
                Logger.getLogger(MenuServiceImpl.class.getName()).log(Level.SEVERE, "Menu n'est pas valide", entity);
                throw new InvalidEntityExceptionCatcher("Menu n'est pas valide", ErrorCodes.Menu_Not_Valid, errors);
            }
            Optional<Menu> currentMenu = entityRepository.findById(entity.getId());
            Menu entityEdit = currentMenu.orElseThrow(() -> new EntityNotFondExceptionCatcher());
            if (entityEdit == null) {
                throw new EntityNotFondExceptionCatcher("Menu non trouvée", ErrorCodes.Menu_Not_Found);
            } else {
                return add(entity);
            }
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

    @Override
    public void delete(Integer id) {
        if (findById(id) != null) {
            try {
                entityRepository.deleteById(id);
            } catch (DataIntegrityViolationException exception) {
                Menu entity = findById(id);
                update(entity);
            }

        }
    }

    @Override
    public List<Menu> findAll() {
        try {
            List<Menu> entitys = entityRepository.findAll();
            if (entitys.isEmpty()) {
                throw new EntityNotFondExceptionCatcher("Pas de entity dans la base de donnée", ErrorCodes.Pas_De_Menu_Dans_La_Base);
            } else {
                return entitys;
            }
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

    @Override
    public Menu findById(Integer id) {
        try {
            if (id == null) {
                Logger.getLogger(MenuServiceImpl.class.getName()).log(Level.SEVERE, "Menu ID NULL");
                return null;
            }
            Optional<Menu> entity = entityRepository.findById(id);
            if (entity.equals(Optional.empty())) {
                throw new EntityNotFondExceptionCatcher("Menu non trouvée", ErrorCodes.Menu_Not_Found);
            }
            return Optional.of(entity.get()).orElseThrow(() -> new EntityNotFondExceptionCatcher("Menu non trouvée", ErrorCodes.Menu_Not_Found));
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

    @Override
    public Menu findByCode(String code) {
        try {
            if (code == null) {
                Logger.getLogger(MenuServiceImpl.class.getName()).log(Level.SEVERE, "Menu ID NULL");
                return null;
            }
            Menu menu = entityRepository.findByCode(code);
            if (menu == null) {
                throw new EntityNotFondExceptionCatcher("Menu non trouvé", ErrorCodes.Menu_Not_Found);
            }
            return menu;
        } catch (EntityNotFondExceptionCatcher exception) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION);
        }
    }

    @Transactional
    @Override
    public void generateAllMenu() {
        try {
            if (entityRepository.findByCode(MenuConstants.UN) == null) {
                add(new Menu(MenuConstants.NOUVELLE_DEMANDE, MenuConstants.UN));
            }
            if (entityRepository.findByCode(MenuConstants.DEUX) == null) {
                add(new Menu(MenuConstants.MES_DEMANDES, MenuConstants.DEUX));
            }
            if (entityRepository.findByCode(MenuConstants.TROIS) == null) {
                add(new Menu(MenuConstants.LISTE_DEMANDES, MenuConstants.TROIS));
            }

            if (entityRepository.findByCode(MenuConstants.QUATRE) == null) {
                add(new Menu(MenuConstants.DEMANDE_A_TRAITER, MenuConstants.QUATRE));
            }
            if (entityRepository.findByCode(MenuConstants.CINQUE) == null) {
                add(new Menu(MenuConstants.DEMANDE_A_CLOTURE, MenuConstants.CINQUE));
            }

            if (entityRepository.findByCode(MenuConstants.SIX) == null) {
                add(new Menu(MenuConstants.DEMANDE_A_VALIDER, MenuConstants.SIX));
            }

            if (entityRepository.findByCode(MenuConstants.SEPT) == null) {
                add(new Menu(MenuConstants.LISTE_PASSEPORT, MenuConstants.SEPT));
            }
            if (entityRepository.findByCode(MenuConstants.HUIT) == null) {
                add(new Menu(MenuConstants.STATISTIQUE, MenuConstants.HUIT));
            }
            if (entityRepository.findByCode(MenuConstants.NEUF) == null) {
                add(new Menu(MenuConstants.ROLE_MENU, MenuConstants.NEUF));
            }
               if (entityRepository.findByCode(MenuConstants.DIX) == null) {
                add(new Menu(MenuConstants.NOUVELLE_VISITE, MenuConstants.DIX));
            }

        } catch (EntityNotFondExceptionCatcher e) {
            throw new EntityNotFondExceptionCatcher("Un problème est survenu lors de l'insertion des menu dans la base des donées", ErrorCodes.PROBLEME_INITIALISATION_BASE_MENU);
        }
    }

}
