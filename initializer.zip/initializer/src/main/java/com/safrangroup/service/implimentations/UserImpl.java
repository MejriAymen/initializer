/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.email.MailUtility;
import com.safrangroup.exception.exceptiongeneric.EntityNotFondExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.ExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.MessagingExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.RoleGlobal;
import com.safrangroup.model.Utilisateur;
import com.safrangroup.repository.RoleGlobalRepository;
import com.safrangroup.repository.UtilisateurRepository;
import com.safrangroup.service.interfaces.UserService;
import com.safrangroup.utils.constant.RoleConstants;
import java.util.ArrayList;
import java.util.List;
import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ala.Nabli
 */
@Service
public class UserImpl implements UserService {

    @Autowired
    UtilisateurRepository repository;
    @Autowired
    RoleGlobalRepository roleGlobalRepository;
    List<String> toAddress;
    List<String> ccAdress;

    public UserImpl() {

    }

    @Override
    public List<Utilisateur> findUsersByRole(Integer id) {
        RoleGlobal roleGlobal = roleGlobalRepository.findById(id).orElseThrow(() -> new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
        return repository.findByRoleGlobal(roleGlobal).orElseThrow(() -> new EntityNotFondExceptionCatcher(ErrorCodes.ENTITY_NOT_FOUND_EXCEPTION));
    }

    @Override
    public void sendMailConcernes() {
        ccAdress = new ArrayList<>();
        toAddress = new ArrayList<>();
        RoleGlobal DIRECTEUR_GENERAL = roleGlobalRepository.findByCode(RoleConstants.DIRECTEUR_GENERAL);
        RoleGlobal COMPTABLE = roleGlobalRepository.findByCode(RoleConstants.COMPTABLE);
        RoleGlobal CHARGER_DEPLACEMENT_PROFESSIONNEL = roleGlobalRepository.findByCode(RoleConstants.CHARGER_DEPLACEMENT_PROFESSIONNEL);
        RoleGlobal RESPONSABLE_RESTAURANT = roleGlobalRepository.findByCode(RoleConstants.CORRESPONDANT_RESTAURANT);
        RoleGlobal CHARGER_SECURITE = roleGlobalRepository.findByCode(RoleConstants.CHARGER_SURETE);
        RoleGlobal DIRECTEUR_RESSOURCES_HUMAINES = roleGlobalRepository.findByCode(RoleConstants.DIRECTEUR_RESSOURCES_HUMAINES);
        RoleGlobal RESPONSABLE_RESSOURCES_HUMAINES = roleGlobalRepository.findByCode(RoleConstants.CORRESPONDANT_RESSOURCES_HUMAINES);
        RoleGlobal RESPONSABLE_COMMUNICATION = roleGlobalRepository.findByCode(RoleConstants.RESPONSABLE_COMMUNICATION);
        RoleGlobal CORRESPONDANT_SSE = roleGlobalRepository.findByCode(RoleConstants.CORRESPONDANT_SSE);
        RoleGlobal FINANCE = roleGlobalRepository.findByCode(RoleConstants.FINANCE);
        List<Utilisateur> usersDG = this.findUsersByRole(DIRECTEUR_GENERAL.getId());
        List<Utilisateur> usersComptable = this.findUsersByRole(COMPTABLE.getId());
        List<Utilisateur> usersChargeDeplacement = this.findUsersByRole(CHARGER_DEPLACEMENT_PROFESSIONNEL.getId());
        List<Utilisateur> usersResponsableRestaurant = this.findUsersByRole(RESPONSABLE_RESTAURANT.getId());
        List<Utilisateur> usersChargerSecurite = this.findUsersByRole(CHARGER_SECURITE.getId());
        List<Utilisateur> usersDRH = this.findUsersByRole(DIRECTEUR_RESSOURCES_HUMAINES.getId());
        List<Utilisateur> usersRRH = this.findUsersByRole(RESPONSABLE_RESSOURCES_HUMAINES.getId());
        List<Utilisateur> usersRC = this.findUsersByRole(RESPONSABLE_COMMUNICATION.getId());
        List<Utilisateur> usersSSE = this.findUsersByRole(CORRESPONDANT_SSE.getId());
        List<Utilisateur> usersFinance = this.findUsersByRole(FINANCE.getId());

        if (usersDG != null && !usersDG.isEmpty()) {
            usersDG.forEach(user -> {
                if (user.getMail() != null) {
                    ccAdress.add(user.getMail());
                }
            });
        }

        if (usersComptable != null && !usersComptable.isEmpty()) {
            usersComptable.forEach(user -> {
                if (user.getMail() != null) {
                    ccAdress.add(user.getMail());
                }
            });
        }
        if (usersChargeDeplacement != null && !usersChargeDeplacement.isEmpty()) {
            usersChargeDeplacement.forEach(user -> {
                if (user.getMail() != null) {
                    toAddress.add(user.getMail());
                }
            });
        }
        if (usersResponsableRestaurant != null && !usersResponsableRestaurant.isEmpty()) {
            usersResponsableRestaurant.forEach(user -> {
                if (user.getMail() != null) {
                    if (user.getMail() != null) {
                        toAddress.add(user.getMail());
                    }
                }
            });
        }
        if (usersChargerSecurite != null && !usersChargerSecurite.isEmpty()) {
            usersChargerSecurite.forEach(user -> {
                if (user.getMail() != null) {
                    ccAdress.add(user.getMail());
                }
            });
        }
        if (usersDRH != null && !usersDRH.isEmpty()) {
            usersDRH.forEach(user -> {
                if (user.getMail() != null) {
                    ccAdress.add(user.getMail());
                }
            });
        }

        if (usersRRH != null && !usersRRH.isEmpty()) {
            usersRRH.forEach(user -> {
                if (user.getMail() != null) {
                    if (user.getMail() != null) {
                        toAddress.add(user.getMail());
                    }
                }
            });
        }
        if (usersRC != null && !usersRC.isEmpty()) {
            usersRC.forEach(user -> {
                if (user.getMail() != null) {
                    ccAdress.add(user.getMail());
                }
            });
        }
        if (usersSSE != null && !usersSSE.isEmpty()) {
            usersSSE.forEach(user -> {
                if (user.getMail() != null) {
                    ccAdress.add(user.getMail());
                }
            });
        }

        if (usersFinance != null && !usersFinance.isEmpty()) {
            usersFinance.forEach(user -> {
                if (user.getMail() != null) {
                    ccAdress.add(user.getMail());
                }
            });
        }

        try {
            if (!toAddress.isEmpty() && !ccAdress.isEmpty()) {
                MailUtility.sendEmail(toAddress, "", "", ccAdress);
            }
        } catch (MessagingException ex) {
            throw new MessagingExceptionCatcher(ErrorCodes.MESSAGING_EXCEPTION);
        } catch (Exception ex) {
            throw new ExceptionCatcher(ErrorCodes.MESSAGING_EXCEPTION);
        }

    }

    @Override
    public void createUserAdminDefault() {
        RoleGlobal DIRECTEUR_GENERAL = roleGlobalRepository.findByCode(RoleConstants.DIRECTEUR_GENERAL);
        if (findUsersByRole(DIRECTEUR_GENERAL.getId()).isEmpty()) {
            Utilisateur u = new Utilisateur("DEFAULT", "DEFAULT", "DEFAULT", "DEFAULT", "DEFAULT", "DEFAULT", Boolean.TRUE, "DEFAULT", 1, DIRECTEUR_GENERAL);
            repository.save(u);
        }
    }
}
