/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.DTO.RegisterFormDataDTO;
import com.safrangroup.DTO.RegisterFormUserDTO;
import com.safrangroup.DTO.UserDTO;
import com.safrangroup.DTO.UserWithTokenDTO;
import com.safrangroup.config.JwtRequest;
import com.safrangroup.config.JwtTokenUtil;
import com.safrangroup.exception.exceptiongeneric.ExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.Connexions;
import com.safrangroup.model.ParametresGeneraux;
import com.safrangroup.model.Utilisateur;
import com.safrangroup.model.ValeursParametre;
import com.safrangroup.repository.ConnexionsRepository;
import com.safrangroup.repository.ParametresGenerauxRepository;
import com.safrangroup.repository.UtilisateurRepository;
import com.safrangroup.repository.ValeursParametreRepository;
import com.safrangroup.service.JwtUserDetailsService;
import com.safrangroup.service.interfaces.JwtAuthenticationService;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ala.Nabli
 */
@Service
public class JwtAuthenticationImpl implements JwtAuthenticationService {

    @Autowired
    public UtilisateurRepository utilisateurRepository;

    @Autowired
    public ValeursParametreRepository valeursParametreRepository;

    @Autowired
    public ParametresGenerauxRepository parametresGenerauxRepository;

    @Autowired
    public AuthenticationManager authenticationManager;

    @Autowired
    public JwtTokenUtil jwtTokenUtil;

    @Autowired
    public JwtUserDetailsService jwtUserDetailsService;

    @Autowired
    public PasswordEncoder bcryptEncoder;

    @Autowired
    public ConnexionsRepository connexionsRepository;

    @Override
    public ResponseEntity<UserWithTokenDTO> createAuthenticationToken(JwtRequest authenticationRequest) {
        try {
            Utilisateur user = null;
            if (utilisateurRepository.getCountUtilisateurByLogin(authenticationRequest.getUsername()) < 2) {
                user = utilisateurRepository.findUtilisateurByLogin(authenticationRequest.getUsername()).orElse(null);
            }
            if (utilisateurRepository.getCountUtilisateurByLogin(authenticationRequest.getUsername()) > 1) {
                user = utilisateurRepository.findUtilisateurByLoginActifAndDefined(authenticationRequest.getUsername()).orElse(null);
            }
            if (user == null) {
                //authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
                String returnString = "{\"redirect\": \"register\"}";
                return new ResponseEntity(returnString, HttpStatus.OK);
                // redirect to register form with 
            } else if (user.getActif()) {
                if (authenticationRequest.getMode() == 2) {
                    if (utilisateurRepository.checkPassword(authenticationRequest.getUsername(), authenticationRequest.getPassword()) == 0) {
                        throw new Exception("password invalid");
                    }
                } else {
                    //authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
                }

                if (user.getIsDefined()) {

                    final UserDetails userDetails = jwtUserDetailsService
                            .loadUserByUsername(authenticationRequest.getUsername());

                    final String token = jwtTokenUtil.generateToken(userDetails);
                    UserDTO userDTO = new UserDTO();
                    userDTO.setId(user.getId());
                    userDTO.setLogin(user.getLogin());
                    userDTO.setMail(user.getMail());
                    userDTO.setNom(user.getNom());
                    userDTO.setPrenom(user.getPrenom());
                    userDTO.setRu(user.getRu());
                    userDTO.setFonction(user.getFonction());
                    userDTO.setUserRole(jwtUserDetailsService.getUserRole(user));
                    if (user.getType() != null && user.getType() == 5) {
                        userDTO.setType(user.getType());
                    }
                    Connexions cnx = new Connexions();
                    cnx.setUtilisateur(user);
                    cnx.setDate(new Date());
                    connexionsRepository.save(cnx);
                    UserWithTokenDTO ut = new UserWithTokenDTO(userDTO, token);

                    return new ResponseEntity(ut, HttpStatus.OK);
                }
                return new ResponseEntity(user, HttpStatus.OK);
            }

            return new ResponseEntity(false, HttpStatus.OK);
        } catch (Exception exception) {
            throw new ExceptionCatcher(ErrorCodes.EXCEPTION);
        }
    }

    @Override
    public RegisterFormDataDTO getRegisterData() {
        try {
            List<RegisterFormUserDTO> users = utilisateurRepository.findUtilisateurByActifOrderByPrenomAsc(true).orElse(null);

            ParametresGeneraux pg;

            pg = parametresGenerauxRepository.findById(6).orElse(null);
            List<ValeursParametre> societes = valeursParametreRepository.findValeursParametreByParametreGeneral(pg).orElse(null);

            pg = parametresGenerauxRepository.findById(1).orElse(null);
            List<ValeursParametre> ru = valeursParametreRepository.findValeursParametreByParametreGeneral(pg).orElse(null);

            RegisterFormDataDTO data = new RegisterFormDataDTO(users, societes, ru);
            return data;
        } catch (Exception exception) {
            throw new ExceptionCatcher(ErrorCodes.EXCEPTION);
        }
    }

    @Override
    public Utilisateur saveUser(Utilisateur user) {
        try {
            Utilisateur newUser = null;
            if (user.getMotDePasse() != null) {
                //(matricule,prenom,nom,mail,fonction,ru,id_sup,login,motDePasse,isDefined,actif,societe)
                utilisateurRepository.addUser(user.getMatricule(), user.getPrenom(), user.getNom(), user.getMail(), user.getFonction(),
                        user.getRu().getId(), user.getSuperieur().getId(),
                        user.getLogin(),
                        user.getMotDePasse(),
                        user.getSociete().getId()
                );
                newUser = new Utilisateur();
                newUser.setMotDePasse("success");
            } else {
                newUser = utilisateurRepository.save(user);
            }

            return newUser;
        } catch (Exception exception) {
            throw new ExceptionCatcher(ErrorCodes.EXCEPTION);
        }
    }

//    public void authenticate(String username, String password) throws Exception {
//
//        String table = "";
//        try {
//            String value = username;
//            // Contient les informations pour initialiser le context
//            Hashtable infos = new Hashtable();
//
//            String domainName = "corp.zodiac.lan";
//            String ad_url = "ldap://corp.zodiac.lan/";
//            String userName = username;
//
//            infos.put(Context.SECURITY_AUTHENTICATION, "simple");
//            infos.put(Context.SECURITY_PRINCIPAL, userName + "@" + domainName);
//            infos.put(Context.SECURITY_CREDENTIALS, password);
//            infos.put(Context.REFERRAL, "follow");
//
//            infos.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
//            infos.put(Context.PROVIDER_URL, ad_url);
//
//            LdapContext ctx = null;
//
//            ctx = new InitialLdapContext(infos, null);
//            System.out.println("LDAP Connection: COMPLETE");
//            SearchControls cons = new SearchControls();
//            cons.setSearchScope(SearchControls.SUBTREE_SCOPE);
//            String[] attrIDs = {"sAMAccountName", "sn", "givenname", "mail", "password"};
//            cons.setReturningAttributes(attrIDs);
//            NamingEnumeration<SearchResult> answer = ctx.search("DC=corp,DC=zodiac,DC=lan", "sAMAccountName=" + userName, cons); //NamingEnumeration<SearchResult> answer = ctx.search("DC=corp,DC=zodiac,DC=lan", "(&(objectCategory=person)(memberOf=CN=SOPHY_USERS,OU=POPULATION,OU=GROUPS,OU=DHARI,OU=SAO,DC=corp,DC=zodiac,DC=lan))", cons);
//            int i = 0;
//            while (answer.hasMore()) {
//                Attributes attrs = answer.next().getAttributes();
//                i++;
//                String mail = "";
//                if (attrs.get("mail") == null) {
//                    mail = "";
//                } else {
//                    mail = attrs.get("mail").get() + "";
//                }
//                System.out.println(attrs.get("password") + "");
//                table = table + "{Firstname:" + attrs.get("givenname").get() + ", Lastname :" + attrs.get("sn").get()
//                        + ", mail:" + mail + "Acountname : " + attrs.get("sAMAccountName").get() + "},";
//                //System.out.println(table);
//            }
//            table = table.substring(0, table.length() - 1);
//            table = "[" + table + "]";
//
//        } catch (Exception e) {
//            System.out.println("error" + e.getMessage());
//            // System.out.println(table);
//            throw new Exception("INVALID_CREDENTIALS", e);
//        }
//    }
}
