/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.interfaces;

import com.safrangroup.DTO.RegisterFormDataDTO;
import com.safrangroup.DTO.UserWithTokenDTO;
import com.safrangroup.config.JwtRequest;
import com.safrangroup.model.Utilisateur;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author Ala.Nabli
 */
public interface JwtAuthenticationService {

    public ResponseEntity<UserWithTokenDTO> createAuthenticationToken(JwtRequest authenticationRequest);

    public RegisterFormDataDTO getRegisterData();

    public Utilisateur saveUser(Utilisateur user);

}
