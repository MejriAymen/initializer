/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.interfaces;

import com.safrangroup.dtos.ResponsePorteuseRoleMenuDTO;
import com.safrangroup.model.PorteuseMenuRole;
import com.safrangroup.model.RoleGlobal;
import com.safrangroup.service.general.CRUDService;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author L258775
 */
public interface PorteuseMenuRoleService extends CRUDService<PorteuseMenuRole> {

    List<PorteuseMenuRole> findByRole(RoleGlobal r);

    void generateAllPorteuseMenuRole();

    List<ResponsePorteuseRoleMenuDTO> findAllPorteusesRolesMenus(Optional<Long> id);

}
