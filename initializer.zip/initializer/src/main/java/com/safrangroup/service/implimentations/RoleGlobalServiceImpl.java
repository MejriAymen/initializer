/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.exception.exceptiongeneric.EntityNotFondExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.ExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.RoleGlobal;
import com.safrangroup.repository.RoleGlobalRepository;
import com.safrangroup.service.interfaces.RoleGlobalService;
import com.safrangroup.utils.constant.RoleConstants;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 *
 * @author L258775
 */
@Slf4j
@Service
public class RoleGlobalServiceImpl implements RoleGlobalService {

    @Autowired
    private RoleGlobalRepository repository;

    @Override
    public ResponseEntity<RoleGlobal> add(RoleGlobal entity) {
        try {
            RoleGlobal newRole = repository.save(entity);
            return new ResponseEntity(newRole, HttpStatus.OK);
        } catch (Exception exception) {
            throw new ExceptionCatcher(ErrorCodes.EXCEPTION);
        }
    }

    @Override
    public ResponseEntity<RoleGlobal> update(RoleGlobal entity) {
        try {
            Optional<RoleGlobal> currentRole = repository.findById(entity.getId());
            RoleGlobal roleEdit = currentRole.orElse(null);
            if (roleEdit == null) {
                return new ResponseEntity("Role not found", HttpStatus.NOT_FOUND);
            } else {
                roleEdit = entity;
                repository.save(roleEdit);
                return new ResponseEntity(roleEdit, HttpStatus.OK);
            }
        } catch (EntityNotFondExceptionCatcher e) {
            throw new EntityNotFondExceptionCatcher(ErrorCodes.ERROR_ELEMENET_NOT_FOUND);
        }
    }

    @Override
    public ResponseEntity delete(Integer id) {
        try {
            Optional<RoleGlobal> deleteRole = repository.findById(id);
            if (deleteRole.orElse(null) == null) {
                return new ResponseEntity("Role not found", HttpStatus.NOT_FOUND);
            }
            repository.delete(deleteRole.get());
            return new ResponseEntity(HttpStatus.OK);
        } catch (Exception exception) {
            throw new ExceptionCatcher(ErrorCodes.EXCEPTION);
        }
    }

    @Override
    public List<RoleGlobal> findAll() {
        return repository.findAll();
    }

    @Override
    public RoleGlobal findById(Integer id) {
        try {
            return repository.findById(id).orElseThrow(() -> new EntityNotFondExceptionCatcher());
        } catch (EntityNotFondExceptionCatcher e) {
            throw new EntityNotFondExceptionCatcher("Role non trouvé", ErrorCodes.Role_Not_Found);
        }

    }

    @Override
    public void addRolesControleAcces() {
        if (repository.findByCode(RoleConstants.DIRECTEUR_GENERAL) == null) {
            add(new RoleGlobal(RoleConstants.DIRECTEUR_GENERAL, RoleConstants.DIRECTEUR_GENERAL));
        }
        if (repository.findByCode(RoleConstants.COMPTABLE) == null) {
            add(new RoleGlobal(RoleConstants.COMPTABLE, RoleConstants.COMPTABLE));
        }

        if (repository.findByCode(RoleConstants.CHARGER_DEPLACEMENT_PROFESSIONNEL) == null) {
            add(new RoleGlobal(RoleConstants.CHARGER_DEPLACEMENT_PROFESSIONNEL, RoleConstants.CHARGER_DEPLACEMENT_PROFESSIONNEL));
        }
        if (repository.findByCode(RoleConstants.CORRESPONDANT_RESTAURANT) == null) {
            add(new RoleGlobal(RoleConstants.CORRESPONDANT_RESTAURANT, RoleConstants.CORRESPONDANT_RESTAURANT));
        }
        if (repository.findByCode(RoleConstants.CHARGER_SURETE) == null) {
            add(new RoleGlobal(RoleConstants.CHARGER_SURETE, RoleConstants.CHARGER_SURETE));
        }

        if (repository.findByCode(RoleConstants.DIRECTEUR_RESSOURCES_HUMAINES) == null) {
            add(new RoleGlobal(RoleConstants.DIRECTEUR_RESSOURCES_HUMAINES, RoleConstants.DIRECTEUR_RESSOURCES_HUMAINES));
        }
        if (repository.findByCode(RoleConstants.CORRESPONDANT_RESSOURCES_HUMAINES) == null) {
            add(new RoleGlobal(RoleConstants.CORRESPONDANT_RESSOURCES_HUMAINES, RoleConstants.CORRESPONDANT_RESSOURCES_HUMAINES));
        }
        if (repository.findByCode(RoleConstants.RESPONSABLE_COMMUNICATION) == null) {
            add(new RoleGlobal(RoleConstants.RESPONSABLE_COMMUNICATION, RoleConstants.RESPONSABLE_COMMUNICATION));
        }
        if (repository.findByCode(RoleConstants.CORRESPONDANT_SSE) == null) {
            add(new RoleGlobal(RoleConstants.CORRESPONDANT_SSE, RoleConstants.CORRESPONDANT_SSE));
        }
        if (repository.findByCode(RoleConstants.FINANCE) == null) {
            add(new RoleGlobal(RoleConstants.FINANCE, RoleConstants.FINANCE));
        }
    }

    @Override
    public RoleGlobal findByCode(String code) {
        try {
            return repository.findByCode(code);
        } catch (EntityNotFondExceptionCatcher e) {
            throw new EntityNotFondExceptionCatcher("Role non trouvé", ErrorCodes.Role_Not_Found);
        }

    }

}
