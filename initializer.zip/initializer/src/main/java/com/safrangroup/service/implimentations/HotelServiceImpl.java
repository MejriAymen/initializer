/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.service.implimentations;

import com.safrangroup.DTO.HotelDto;
import com.safrangroup.exception.exceptiongeneric.EntityNotFondExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.ExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.InvalidEntityExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.model.Hotel;
import com.safrangroup.repository.HotelRepository;
import com.safrangroup.service.interfaces.HotelService;
import com.safrangroup.validator.HotelValidator;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

/**
 *
 * @author L258775
 */
@Service
public class HotelServiceImpl implements HotelService {

    private final HotelRepository repository;

    public HotelServiceImpl(HotelRepository repository) {
        this.repository = repository;
    }

    @Override
    public HotelDto add(HotelDto hotelDto) {
        List<String> errors = HotelValidator.validate(HotelDto.fromDto(hotelDto));
        if (!errors.isEmpty()) {
            throw new InvalidEntityExceptionCatcher("Hotel n'est pas valide", ErrorCodes.HOTEL_Not_Valid, errors);
        }
        return HotelDto.toDto(repository.save(HotelDto.fromDto(hotelDto)));

    }

    @Override
    public HotelDto update(HotelDto hotelDto) {

        List<String> errors = HotelValidator.validate(HotelDto.fromDto(hotelDto));
        if (!errors.isEmpty()) {
            Logger.getLogger(HotelServiceImpl.class.getName()).log(Level.SEVERE, "Hotel n'est pas valide", hotelDto);
            throw new InvalidEntityExceptionCatcher("Hotel n'est pas valide", ErrorCodes.HOTEL_Not_Valid, errors);
        }
        Optional<Hotel> currentHotel = (Optional<Hotel>) (Object) repository.findById(hotelDto.getId());
        Hotel hotelEdit = currentHotel.orElse(null);
        if (hotelEdit == null) {
            throw new EntityNotFondExceptionCatcher("Hotel non trouvée", ErrorCodes.HOTEL_Not_Found);
        } else {
            return add(hotelDto);
        }
    }

    @Override
    public void delete(Integer id) {
        if (findById(id) != null) {
            try {
                repository.deleteById(id);
            } catch (DataIntegrityViolationException exception) {
                Hotel hotel = HotelDto.fromDto(findById(id));
                hotel.setVisible(Boolean.FALSE);
                update(HotelDto.toDto(hotel));
            }

        }
    }

    @Override
    public List<HotelDto> findAll() {
        List<Hotel> hotels = (List<Hotel>) (Object) repository.findAll();
        if (hotels.isEmpty()) {
            throw new EntityNotFondExceptionCatcher("Pas de hotel dans la base de donnée", ErrorCodes.Pas_De_HOTEL_Dans_La_Base);
        } else {
            return hotels.stream().map(HotelDto::toDto).collect(Collectors.toList());
        }
    }

    @Override
    public HotelDto findById(Integer id) {
        if (id == null) {
            Logger.getLogger(HotelServiceImpl.class.getName()).log(Level.SEVERE, "Hotel ID NULL");
            return null;
        }
        Optional<Hotel> hotel = (Optional<Hotel>) (Object) repository.findById(id);
        if (hotel.equals(Optional.empty())) {
            throw new EntityNotFondExceptionCatcher("Hotel non trouvée", ErrorCodes.HOTEL_Not_Found);
        }
        return Optional.of(HotelDto.toDto(hotel.get())).orElseThrow(() -> new EntityNotFondExceptionCatcher("Hotel non trouvée", ErrorCodes.HOTEL_Not_Found));
    }

    @Override
    public void renfrocementBaseHotel() {
        try {
            if (repository.findByLibelle("Novotel") == null) {
                this.add(new HotelDto("Novotel"));
            }
            if (repository.findByLibelle("Ibis Tunis") == null) {
                this.add(new HotelDto("Ibis Tunis"));
            }
            if (repository.findByLibelle("Barcélo Concorde") == null) {
                this.add(new HotelDto("Barcélo Concorde"));
            }
            if (repository.findByLibelle("Laico") == null) {
                this.add(new HotelDto("Laico"));
            }
        } catch (Exception e) {
            throw new ExceptionCatcher("Erreur lors de renfrocement base hôtels", ErrorCodes.EXCEPTION);
        }

    }

}
