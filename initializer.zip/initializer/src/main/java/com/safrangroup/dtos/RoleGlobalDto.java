/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.dtos;

import com.safrangroup.model.RoleGlobal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Ala.Nabli
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleGlobalDto {

    Integer id;
    String name;
    String code;

    public static RoleGlobalDto fromEntity(RoleGlobal roleGlobal) {
        if (roleGlobal == null) {
            return null;
        }
        return RoleGlobalDto.builder().id(roleGlobal.getId()).code(roleGlobal.getCode()).name(roleGlobal.getName()).build();
    }

    public static RoleGlobal fromDto(RoleGlobalDto roleGlobalDto) {
        if (roleGlobalDto == null) {
            return null;
        }

        RoleGlobal roleGlobal = new RoleGlobal(roleGlobalDto.getName(), roleGlobalDto.getCode());
        roleGlobal.setId(roleGlobal.getId());
        return roleGlobal;
    }

}
