/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.dtos;

import com.safrangroup.model.PorteuseMenuRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author L60018794
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PorteuseMenuRoleDto {

    Integer id;
    RoleGlobalDto roleGlobalDto;
    MenuDto menuDto;
    Boolean genertion;
    Boolean consultation;
    Boolean ajout;
    Boolean modification;
    Boolean suppression;

    public static PorteuseMenuRoleDto fromEntity(PorteuseMenuRole porteuseMenuRole) {
        if (porteuseMenuRole == null) {
            return null;
        }
        return PorteuseMenuRoleDto.builder().id(porteuseMenuRole.getId()).genertion(porteuseMenuRole.getGenertion()).consultation(porteuseMenuRole.getConsultation()).ajout(porteuseMenuRole.getAjout()).modification(porteuseMenuRole.getModification()).suppression(porteuseMenuRole.getSuppression()).menuDto(MenuDto.fromEntity(porteuseMenuRole.getMenu())).roleGlobalDto(RoleGlobalDto.fromEntity(porteuseMenuRole.getRole())).build();
    }

    public static PorteuseMenuRole fromDto(PorteuseMenuRoleDto porteuseMenuRoleDto) {
        if (porteuseMenuRoleDto == null) {
            return null;
        }

        PorteuseMenuRole porteuseMenuRole = new PorteuseMenuRole(RoleGlobalDto.fromDto(porteuseMenuRoleDto.getRoleGlobalDto()), MenuDto.fromDto(porteuseMenuRoleDto.getMenuDto()), porteuseMenuRoleDto.getGenertion(), porteuseMenuRoleDto.getConsultation(), porteuseMenuRoleDto.getAjout(), porteuseMenuRoleDto.getModification(), porteuseMenuRoleDto.getSuppression());
        porteuseMenuRole.setId(porteuseMenuRoleDto.getId());
        return porteuseMenuRole;
    }

}
