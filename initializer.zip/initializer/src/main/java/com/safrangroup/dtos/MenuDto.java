/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.dtos;

import com.safrangroup.model.Menu;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author L60018794
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MenuDto {

    Integer id;
    String libelle;
    String code;

    public static MenuDto fromEntity(Menu menu) {
        if (menu == null) {
            return null;
        }
        return MenuDto.builder().id(menu.getId()).libelle(menu.getLibelle()).code(menu.getCode()).build();
    }

    public static Menu fromDto(MenuDto menuDto) {
        if (menuDto == null) {
            return null;
        }

        Menu menu = new Menu(menuDto.getLibelle(), menuDto.getCode());
        menu.setId(menuDto.getId());
        return menu;
    }

}
