/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.repository;

import com.safrangroup.model.Menu;
import com.safrangroup.model.PorteuseMenuRole;
import com.safrangroup.model.RoleGlobal;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author L258775
 */
public interface PorteuseMenuRoleRepository extends JpaRepository<PorteuseMenuRole, Integer> {

    List<PorteuseMenuRole> findByRole(RoleGlobal r);

    PorteuseMenuRole findByRoleAndMenu(RoleGlobal r, Menu m);

    @Query(value = "select r.name,m.code,m.libelle,prm.ajout,prm.consultation,prm.modification,prm.suppression,prm.genertion,m.id from porteusemenurole prm inner join menu m on m.id=prm.menu_id inner join roleglobal r on r.id = prm.role_id  group by r.name,m.code,m.libelle,prm.ajout,prm.consultation,prm.modification,prm.suppression,prm.genertion,m.id,r.id order by r.id asc", nativeQuery = true)
    List<Object[]> findAllPorteusesRolesMenus();

    @Query(value = "select r.name,m.code,m.libelle,prm.ajout,prm.consultation,prm.modification,prm.suppression,prm.genertion,m.id from porteusemenurole prm inner join menu m on m.id=prm.menu_id inner join roleglobal r on r.id = prm.role_id where role_id= :id group by r.name,m.code,m.libelle,prm.ajout,prm.consultation,prm.modification,prm.suppression,prm.genertion,m.id,r.id order by r.id asc", nativeQuery = true)
    List<Object[]> findAllPorteusesRolesMenus(@Param("id") Optional<Long> id);
}
