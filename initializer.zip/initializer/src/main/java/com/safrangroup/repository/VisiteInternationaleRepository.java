/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.repository;

import com.safrangroup.model.VisiteInternationale;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Ala.Nabli
 */
public interface VisiteInternationaleRepository extends JpaRepository<VisiteInternationale, Integer> {

    List<VisiteInternationale> findByDateWithoutTime(Date d);
}
