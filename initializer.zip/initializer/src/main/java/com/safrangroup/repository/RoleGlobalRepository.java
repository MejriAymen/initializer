/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.repository;

import com.safrangroup.model.RoleGlobal;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author L258775
 */
public interface RoleGlobalRepository extends JpaRepository<RoleGlobal, Integer> {

    RoleGlobal findByCode(String code);
}
