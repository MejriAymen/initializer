/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.repository;

import com.safrangroup.model.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 *
 * @author Ala.Nabli
 */
public interface HotelRepository extends JpaRepository<Hotel, Integer> {
Hotel findByLibelle(String libelle);
   @Query(value = "select max(id) from hotel", nativeQuery = true)
    Integer findMaxId();}
