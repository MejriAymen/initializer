/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.repository;

import com.safrangroup.DTO.RegisterFormUserDTO;
import com.safrangroup.model.RoleGlobal;
import com.safrangroup.model.Utilisateur;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Ala.Nabli
 */
public interface UtilisateurRepository extends JpaRepository<Utilisateur, Integer> {

    public Optional<List<Utilisateur>> findByRoleGlobal(RoleGlobal roleGlobal);

    public Optional<Utilisateur> findUtilisateurByType(Integer type);

    @Query(value = "SELECT * FROM utilisateur WHERE UPPER(login) = UPPER(?1)",
            nativeQuery = true)
    public Optional<Utilisateur> findUtilisateurByLogin(String login);

    @Query(value = "SELECT * FROM utilisateur WHERE UPPER(login) = UPPER(?1) and actif = 1 AND isDefined = 1 ",
            nativeQuery = true)
    public Optional<Utilisateur> findUtilisateurByLoginActifAndDefined(String login);

    @Query(value = "SELECT COUNT(*) FROM utilisateur WHERE UPPER(login) = UPPER(?1)",
            nativeQuery = true)
    Integer getCountUtilisateurByLogin(String login);

    public Optional<List<RegisterFormUserDTO>> findUtilisateurByActifOrderByPrenomAsc(Boolean actif);

    public Optional<List<Utilisateur>> findUtilisateurBySuperieur(Utilisateur superieur);

    @Query(value = "SELECT id FROM utilisateur WHERE id_sup = ?1",
            nativeQuery = true)
    public Optional<List<Integer>> getFirstUsersIdList(Integer userId);

    @Query(value = "SELECT id FROM utilisateur WHERE id_sup in ?1",
            nativeQuery = true)
    public Optional<List<Integer>> getUsersIdListByUserIdList(List<Integer> usersIdList);

    @Query(value = "select count(id) from utilisateur where login=?1 and motDePasse=HASHBYTES('MD5',?2) and actif=1", nativeQuery = true)
    public int checkPassword(String login, String password);

    @Transactional
    @Modifying
    @Query(value = "insert into utilisateur (matricule,prenom,nom,mail,fonction,ru,id_sup,login,motDePasse,isDefined,actif,societe) \n"
            + "  values(?1,?2,?3,?4,?5,?6,?7,?8,HASHBYTES('MD5',?9),'1','1',?10)", nativeQuery = true)
    public void addUser(String matricule, String prenom, String nom, String mail, String fonction, Integer idRu, Integer idSup, String login, String password, Integer societeId);

    @Query(value = "select * from utilisateur where motDePasse is not null", nativeQuery = true)
    public List<Utilisateur> getUsersWithPassword();

    @Transactional
    @Modifying
    @Query(value = "update utilisateur set motDePasse=HASHBYTES('MD5',?1) where id =?2", nativeQuery = true)
    public void updatePasswords(String password, Integer id);
}
