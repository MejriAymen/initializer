/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.utils.constant;

/**
 *
 * @author L60018794
 */
public interface MessagesConstants {

String MESSAGE_EXCEPTION_ERROR_SAVE_VISITE="Lors de l'enregistrement visite";
}
