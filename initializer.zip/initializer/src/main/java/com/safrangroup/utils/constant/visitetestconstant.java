/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.utils.constant;

/**
 *
 * @author L60018794
 */
public interface visitetestconstant {

      String NUM_PASSPORT="0911111447L";
      String NOM1="Mejri";
      String PRENOM1="AYMEN";
      String NOM2="Ayari";
      String PRENOM2="Lamjed";
      String FONCTION1="Responsable pôle développement IT";
      String FONCTION2="Ingénieur";
      String CIN="09161017";
      String NUM_TELEPHONE="20-117-417";
      String NUM_VIS_A_VIS="58-958-254";
      String CONTACT_URGENCE="";
}
