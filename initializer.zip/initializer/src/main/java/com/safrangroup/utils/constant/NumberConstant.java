/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.utils.constant;

/**
 *
 * @author L60018794
 */
public interface NumberConstant {

    long MAX_SIZE = 1000000;
    Integer ZERO = 0;
    Integer UN = 1;
    Integer DEUX = 2;
    Integer TROIS = 3;
    Integer QUATRE = 4;
    Integer CINQUE = 5;
    Integer SIX = 6;
    Integer SEPT = 7;
    Integer HUIT = 8;
    Integer NEUF = 9;
    Integer DIX = 10;
    Integer ONZE = 11;
    Integer DOUZE = 12;
}
