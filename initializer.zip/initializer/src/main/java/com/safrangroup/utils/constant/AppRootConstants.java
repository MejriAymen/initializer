package com.safrangroup.utils.constant;

public interface AppRootConstants {

    String APP_ROOT_BILLET = "/billet";
    String APP_ROOT_CHANGE_BANQUE = "/changeBanque";
    String APP_ROOT_DEMANDE = "/demande";
    String APP_ROOT_FACTURE = "/facture";
    String APP_ROOT_FICHIER_SECURITE = "/fichierSecurite";
    String APP_ROOT_FRAIS = "/frais";
    String APP_ROOT_PASSEPORT = "/passeport";
    String APP_ROOT_REGLEMENT = "/reglement";
    String APP_ROOT_STATISTIQUE = "/statistique";
    String APP_ROOT_VALEUR_PARAMETRE = "/valeurParametre";
    String APP_ROOT_VALIDATION = "/validation";
    String APP_ROOT_VOITURE = "/voiture";
    String APP_ROOT_PORTEUSE_ROLE_MENU = "/menu";
    String APP_ROOT_VISITE = "/visite";
    String APP_ROOT_HOTEL = "/hotel";
    String APP_ROOT_SOCIETE_EXTERNE = "/societeexterne";
}
