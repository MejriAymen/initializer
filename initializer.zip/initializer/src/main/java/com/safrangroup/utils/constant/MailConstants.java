/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.utils.constant;

/**
 * @author L60018794
 */
public interface MailConstants {

    String MAIL_HOST = "mail.smtp.host";
    String HOST = "11.1.208.50";
    String MAIL_PORT = "mail.smtp.port";
    String PORT = "25";
    String MAIL_AUTH = "mail.smtp.auth";
    String AUTH = "true";
    String MAIL_STARTTLS = "mail.smtp.starttls.enable";
    String STARTTLS = "true";
}
