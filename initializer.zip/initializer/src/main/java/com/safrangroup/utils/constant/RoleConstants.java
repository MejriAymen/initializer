/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.utils.constant;

/**
 *
 * @author L60018794
 */
public interface RoleConstants {

  /*
    Rôles Globales BASE VISITEURS
     */
    String DIRECTEUR_GENERAL = "DIRECTEUR_GENERAL";
    String DIRECTEUR_RESSOURCES_HUMAINES = "DIRECTEUR_RESSOURCES_HUMAINES";
    String CHARGER_SURETE = "CHARGER_SURETE";
    String CHARGER_DEPLACEMENT_PROFESSIONNEL = "CHARGER_DEPLACEMENT_PROFESSIONNEL";
    String RESPONSABLE_COMMUNICATION = "RESPONSABLE_COMMUNICATION";
    String CORRESPONDANT_RESTAURANT = "CORRESPONDANT_RESTAURANT";
    String CORRESPONDANT_RESSOURCES_HUMAINES = "CORRESPONDANT_RESOURCES_HUMAINES";
    String CORRESPONDANT_SSE = "CORRESPONDANT_SSE";
    String CODIR = "CODIR";
    String FINANCE = "FINANCE";
    String CONSULTANT = "CONSULTANT";
    final String RESPONSABLE = "RESPONSABLE";
    /*
    Rôles globales E-TRAVEL
     */
    String COMPTABLE = "COMPTABLE";

    /*
    AUTHORITIES
     */
    String PACK_URL = "hasAuthority(T(com.safrangroup.utils.constant.RoleConstants).";
    String TLD = ")||";
    String PARENTHESE = ")";
}
