/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.utils.mapper;

//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.safrangroup.exception.exceptiongeneric.IOExceptionCatcher;
import com.safrangroup.exception.exceptiongeneric.JsonProcessingExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.Data;

/**
 *
 * @author L60018794
 */
@Data
//@JsonIgnoreProperties(ignoreUnknown = true)
class Laptop {

    private String brand;
    private String model;

    public Laptop() {
    }

    public Laptop(String brand, String model) {
        this.brand = brand;
        this.model = model;
    }
}

public class ObjectMapperDemo {

    /*
    Frontend ---JSON String---> Deserialization-----java Object--->  Backend
     */
    static Laptop deserializationJsontoLaptopObject() {
        String json = "{\"brand\":\"ABC\",\"model\":\"XY1\"}";
//        String json = "{\"brand\":\"ABC\",\"model\":\"XYZ\"}";
        ObjectMapper mapper = new ObjectMapper();
        try {
            Laptop l = mapper.readValue(json, Laptop.class);
            System.out.println("Serialiszation to object : " + l);
            return l;
        } catch (JsonProcessingException ex) {
            throw new JsonProcessingExceptionCatcher(ErrorCodes.JSON_PROCESSING_EXCEPTION);
        }
    }

    static Laptop[] deserializationJsonStringArrayToLaptopArrayOfObjects() {
        String json = "[{\"brand\":\"ABC\",\"model\":\"XY1\"}"
                + ",{\"brand\":\"DEF\",\"model\":\"XY2\"}"
                + ",{\"brand\":\"JEH\",\"model\":\"XY3\"}"
                + "]";
        ObjectMapper mapper = new ObjectMapper();
        try {
            Laptop[] list = mapper.readValue(json, Laptop[].class);
            for (Laptop laptop : list) {
                System.out.println("Serialiszation to array of objects : " + laptop);
            }
            return list;
        } catch (JsonProcessingException ex) {
            throw new JsonProcessingExceptionCatcher(ErrorCodes.JSON_PROCESSING_EXCEPTION);
        }
    }

    static List<Laptop> deserializationJsonStringArrayToListOfLaptopObjects() {
        String json = "[{\"brand\":\"ABC\",\"model\":\"XY1\"}"
                + ",{\"brand\":\"DEF\",\"model\":\"XY2\"}"
                + ",{\"brand\":\"JEH\",\"model\":\"XY3\"}"
                + "]";
        ObjectMapper mapper = new ObjectMapper();
        try {
            List<Laptop> list = mapper.readValue(json, new TypeReference<List<Laptop>>() {
            });
            list.forEach((laptop) -> {
                System.out.println("Serialiszation to List of objects : " + laptop);
            });
            return list;
        } catch (JsonProcessingException ex) {
            throw new JsonProcessingExceptionCatcher(ErrorCodes.JSON_PROCESSING_EXCEPTION);
        }
    }

    static Map<String, String> deserializationJsonStringToAmapOfObjects() {
        String json = "{\"brand\":\"ABC\",\"model\":\"XYZ\"}";
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, String> map = mapper.readValue(json, new TypeReference<Map<String, String>>() {
            });
            map.keySet().forEach((key) -> {
                System.out.println("Key " + key);
                System.out.println("Value " + map.get(key));
            });
            return map;
        } catch (JsonProcessingException ex) {
            throw new JsonProcessingExceptionCatcher(ErrorCodes.JSON_PROCESSING_EXCEPTION);
        }
    }

    /*
    Reverse
    Frontend ---JSON String---> Serialization-----java Object------  Backend
     */
    static String serializeObjectToJson() {
        try {
            Laptop laptop = new Laptop("brand", "ABC");
            Laptop laptop2 = new Laptop("brand", "ABC");
            List laptops = new ArrayList<>();
            laptops.add(laptop);
            laptops.add(laptop2);
            ObjectMapper mapper = new ObjectMapper();
            StringWriter writer = new StringWriter();
            mapper.writeValue(writer, laptops);
            String json = writer.toString();
            System.out.println("Serilisation : " + json);
            return json;
        } catch (IOException ex) {
            throw new IOExceptionCatcher(ErrorCodes.IO_EXCEPTION);
        }
    }

    public static void main(String[] args) {
        deserializationJsontoLaptopObject();
        deserializationJsonStringArrayToLaptopArrayOfObjects();
        deserializationJsonStringArrayToListOfLaptopObjects();
        deserializationJsonStringToAmapOfObjects();
        serializeObjectToJson();
    }

}
