/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.utils.constant;

/**
 *
 * @author L60018794
 */
public interface MenuConstants {

    String NOUVELLE_DEMANDE = "Nouvelle demande";
    String MES_DEMANDES = "Mes demandes";
    String LISTE_DEMANDES = "Liste des demandes";
    String DEMANDE_A_TRAITER = "Demandes à traiter";
    String DEMANDE_A_CLOTURE = "Demandes à clôturer";
    String DEMANDE_A_VALIDER = "Demandes à valider";
    String LISTE_PASSEPORT = "Liste des passeports";
    String STATISTIQUE = "Statistiques";
    String ROLE_MENU = "Rôle_Menu";
    String NOUVELLE_VISITE = "Nouvelle visite";
    
    String UN = "1";
    String DEUX = "2";
    String TROIS = "3";
    String QUATRE = "4";
    String CINQUE = "5";
    String SIX = "6";
    String SEPT = "7";
    String HUIT = "8";
    String NEUF = "9";
       String DIX = "10";
}
