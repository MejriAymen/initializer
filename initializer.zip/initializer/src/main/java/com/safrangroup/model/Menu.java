/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.BaseEntity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author L60018794
 */
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@SequenceGenerator(name = "default_gen", sequenceName = "menu_seq", allocationSize = 1)
public class Menu extends BaseEntity {

    @Column(nullable = false, unique = true)
    String libelle;
    @Column(nullable = false, unique = true)
    String code;

}
