/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.BaseEntity;
import javax.persistence.*;

/**
 *
 * @author Ala.Nabli
 */
@Entity
@Table(name = "parametresGeneraux")
@SequenceGenerator(name = "default_gen", sequenceName = "parametre_genereaux_seq", allocationSize = 1)
public class ParametresGeneraux extends BaseEntity {

    private String intitule;
    private Boolean actif;

    public ParametresGeneraux() {
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    public Boolean getActif() {
        return actif;
    }

    public void setActif(Boolean actif) {
        this.actif = actif;
    }

}
