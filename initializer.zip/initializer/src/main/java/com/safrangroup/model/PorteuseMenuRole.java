/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.safrangroup.model.inhertance.BaseEntity;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author L60018794
 */
@Builder
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@SequenceGenerator(name = "default_gen", sequenceName = "porteuse_menu_role_seq", allocationSize = 1)
public class PorteuseMenuRole extends BaseEntity {

    @JsonIgnore
    @ManyToOne
    RoleGlobal role;
    @ManyToOne
    Menu menu;
    Boolean genertion;
    Boolean consultation;
    Boolean ajout;
    Boolean modification;
    Boolean suppression;

}
