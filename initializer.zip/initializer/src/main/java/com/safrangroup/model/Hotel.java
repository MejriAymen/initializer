/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.BaseEntity;
import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 *
 * @author Ala.Nabli
 */
@Builder
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@SequenceGenerator(name = "default_gen", sequenceName = "hotel_seq", allocationSize = 1)
public class Hotel extends BaseEntity {

    @Column(nullable = false, unique = false)
    String libelle;
    String info;
    @Column(unique = false)
    String tel;
    Boolean visible;

    public Hotel(String libelle) {
        this.libelle = libelle;
    }

}
