/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model.inhertance;

import com.safrangroup.model.Circuit;
import com.safrangroup.model.Utilisateur;
import com.safrangroup.model.ValeursParametre;
import com.safrangroup.utils.DateManagement;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@NoArgsConstructor
@Getter
@Setter
@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type_visite", discriminatorType = DiscriminatorType.STRING)
@Table(name = "visite")
@SequenceGenerator(name = "default_gen", sequenceName = "visite_seq", allocationSize = 1)
public class Visite extends BaseEntity {

    String intitule;
    String objectif;
    @Temporal(javax.persistence.TemporalType.DATE)
    Date dateWithoutTime;
    LocalDateTime dateCreation;
    LocalDateTime dateVisite;
    Boolean restaurantPriseEnCharge;
    Boolean reunionCodir;
    Boolean cadeau;
    Boolean presentationSafran;
    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<Circuit> circuits;
    @ManyToOne
    @JoinColumn(name = "site_juridique_id")
    ValeursParametre societeJuridique;
    @ManyToOne
    Utilisateur utilisateur;

    public Visite(String intitule, String objectif, LocalDateTime dateVisite, Boolean restaurantPriseEnCharge, Boolean reunionCodir, Boolean cadeau, Boolean presentationSafran, List<Circuit> circuits, ValeursParametre societeJuridique, Utilisateur utilisateur) {
        this.intitule = intitule;
        this.objectif = objectif;
        this.dateVisite = dateVisite;
        this.restaurantPriseEnCharge = restaurantPriseEnCharge;
        this.reunionCodir = reunionCodir;
        this.cadeau = cadeau;
        this.presentationSafran = presentationSafran;
        this.circuits = circuits;
        this.societeJuridique = societeJuridique;
        this.utilisateur = utilisateur;
        this.dateCreation = LocalDateTime.now();
        dateWithoutTime = DateManagement.dateFromLacalDateTime(dateVisite);
    }

}
