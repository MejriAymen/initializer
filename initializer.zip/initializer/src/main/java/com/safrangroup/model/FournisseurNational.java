/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.Fournisseur;
import java.time.LocalDateTime;
import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@DiscriminatorColumn(name = "Fournisseur_National")
@SequenceGenerator(name = "default_gen", sequenceName = "fournisseur_national_seq", allocationSize = 1)
public class FournisseurNational extends Fournisseur {

    public FournisseurNational(String mail, String nom, String prenom, String fonction, String cin, String numTelephone, String numVisAVis, Integer dureeIntervention, String contactUrgence, String photo, LocalDateTime heuredeb, LocalDateTime heureFin, SocieteExterne societeExterne) {
        super(mail, nom, prenom, fonction, cin, numTelephone, numVisAVis, dureeIntervention, contactUrgence, photo, heuredeb, heureFin, societeExterne);
    }

}
