/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.BaseEntity;
import java.time.LocalDateTime;
import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "circuit")
public class Circuit extends BaseEntity implements Comparable<Circuit> {

    @ManyToOne
    @JoinColumn(name = "ru_id")
    ValeursParametre valeursParametre;
    private LocalDateTime heureDebut;
    private LocalDateTime heureFin;
    Integer duree;
    Integer priorite;

    @Override
    public int compareTo(Circuit o) {
        return this.priorite - o.getPriorite();
    }

    
    
    public Circuit(LocalDateTime heureDebut, LocalDateTime heureFin, Integer duree, Integer priorite,ValeursParametre valeursParametre) {
        this.heureDebut = heureDebut;
        this.heureFin = heureFin;
        this.duree = duree;
        this.priorite = priorite;
        this.valeursParametre=valeursParametre;
    }

}
