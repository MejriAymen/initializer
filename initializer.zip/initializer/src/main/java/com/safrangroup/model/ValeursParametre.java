/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.BaseEntity;
import javax.persistence.*;

/**
 *
 * @author Ala.Nabli
 */
@Entity
@Table(name = "valeursParametre")
@SequenceGenerator(name = "default_gen", sequenceName = "valeurs_paraametre_seq", allocationSize = 1)
public class ValeursParametre extends BaseEntity {

    @Column(name = "valeurParametre")
    private String valeurParametre;
    private Integer ordre;
    private Boolean actif;
    @ManyToOne
    @JoinColumn(name = "id_parametre")
    private ParametresGeneraux parametreGeneral;

    public ValeursParametre() {
    }

    public ValeursParametre(String valeurParametre, Integer ordre, Boolean actif) {
        this.valeurParametre = valeurParametre;
        this.ordre = ordre;
        this.actif = actif;
    }

    public ValeursParametre(String valeurParametre) {
        this.valeurParametre = valeurParametre;
    }

    public String getValeurParametre() {
        return valeurParametre;
    }

    public void setValeurParametre(String valeurParametre) {
        this.valeurParametre = valeurParametre;
    }

    public Integer getOrdre() {
        return ordre;
    }

    public void setOrdre(Integer ordre) {
        this.ordre = ordre;
    }

    public Boolean getActif() {
        return actif;
    }

    public void setActif(Boolean actif) {
        this.actif = actif;
    }

    public ParametresGeneraux getParametreGeneral() {
        return parametreGeneral;
    }

    public void setParametreGeneral(ParametresGeneraux parametreGeneral) {
        this.parametreGeneral = parametreGeneral;
    }

}
