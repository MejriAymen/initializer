/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.Visite;
import java.time.LocalDateTime;
import java.util.List;
import javax.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@NoArgsConstructor
@Getter
@Setter
@Entity
@EqualsAndHashCode(callSuper = true)
@DiscriminatorColumn(name = "Visite_Internationale")
@Table(name = "VisiteInternationale")
@SequenceGenerator(name = "default_gen", sequenceName = "visite_internationale_seq", allocationSize = 1)
public class VisiteInternationale extends Visite {

    String numeroVolAller;
    String numeroVolRetour;
    LocalDateTime dateArriveEnTunisie;
    LocalDateTime dateArriveeSurSite;
    LocalDateTime dateDeparTunisie;
    Boolean sejourPriseEnCharge;
    Boolean netCarPriseEnCharge;
    @ManyToOne
    Hotel hotel;
    Integer nbrJrsReservationHotel;
    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<VisiteurGroupe> visiteurGroupes;
    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<VisiteurClient> visiteurClients;
    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<VisiteurAuditeur> visiteurAuditeurs;
    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<VisiteurPrestataire> visiteurPrestataires;
    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<FournisseurInterNational> fournisseurInterNationals;

    public VisiteInternationale(String numeroVolAller, String numeroVolRetour, LocalDateTime dateArriveEnTunisie, LocalDateTime dateArriveeSurSite, LocalDateTime dateDeparTunisie, Boolean sejourPriseEnCharge, Boolean netCarPriseEnCharge, Hotel hotel, Integer nbrJrsReservationHotel, String intitule, String objectif, LocalDateTime dateVisite, Boolean restaurantPriseEnCharge, Boolean reunionCodir, Boolean cadeau, Boolean presentationSafran, List<Circuit> circuits, ValeursParametre societeJuridique, Utilisateur utilisateur, List<Object> visiteurs) {
        super(intitule, objectif, dateVisite, restaurantPriseEnCharge, reunionCodir, cadeau, presentationSafran, circuits, societeJuridique, utilisateur);
        this.numeroVolAller = numeroVolAller;
        this.numeroVolRetour = numeroVolRetour;
        this.dateArriveEnTunisie = dateArriveEnTunisie;
        this.dateArriveeSurSite = dateArriveeSurSite;
        this.dateDeparTunisie = dateDeparTunisie;
        this.sejourPriseEnCharge = sejourPriseEnCharge;
        this.netCarPriseEnCharge = netCarPriseEnCharge;
        this.hotel = hotel;
        this.nbrJrsReservationHotel = nbrJrsReservationHotel;
        if (visiteurs != null && !visiteurs.isEmpty()) {
            if (visiteurs.get(0) instanceof VisiteurGroupe) {
                this.visiteurGroupes = (List<VisiteurGroupe>) (Object) visiteurs;
            } else if (visiteurs.get(0) instanceof VisiteurClient) {
                this.visiteurClients = (List<VisiteurClient>) (Object) visiteurs;
            } else if (visiteurs.get(0) instanceof VisiteurAuditeur) {
                this.visiteurAuditeurs = (List<VisiteurAuditeur>) (Object) visiteurs;
            } else if (visiteurs.get(0) instanceof VisiteurPrestataire) {
                this.visiteurPrestataires = (List<VisiteurPrestataire>) (Object) visiteurs;
            } else if (visiteurs.get(0) instanceof FournisseurInterNational) {
                this.fournisseurInterNationals = (List<FournisseurInterNational>) (Object) visiteurs;
            }
        }
    }

}
