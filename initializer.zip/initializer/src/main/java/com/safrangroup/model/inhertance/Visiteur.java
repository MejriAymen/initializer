/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model.inhertance;

import com.safrangroup.model.SocieteExterne;
import java.time.LocalDateTime;
import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type_visiteur", discriminatorType = DiscriminatorType.STRING)
@Table(name = "visiteur")
@SequenceGenerator(name = "default_gen", sequenceName = "visiteur_seq", allocationSize = 1)
public class Visiteur extends BaseEntity {

    String nom;
    String prenom;
    String fonction;
    String cin;
    String numTelephone;
    String numVisAVis;
    Integer dureeIntervention;
    String contactUrgence;
    String photo;
    LocalDateTime heuredeb;
    LocalDateTime heureFin;
    @ManyToOne
    SocieteExterne societeExterne;

    public Visiteur(String nom, String prenom, String fonction, String cin, String numTelephone, String numVisAVis, Integer dureeIntervention, String contactUrgence, String photo, LocalDateTime heuredeb, LocalDateTime heureFin, SocieteExterne societeExterne) {
        this.nom = nom;
        this.prenom = prenom;
        this.fonction = fonction;
        this.cin = cin;
        this.numTelephone = numTelephone;
        this.numVisAVis = numVisAVis;
        this.dureeIntervention = dureeIntervention;
        this.contactUrgence = contactUrgence;
        this.photo = photo;
        this.heuredeb = heuredeb;
        this.heureFin = heureFin;
        this.societeExterne = societeExterne;
    }

}
