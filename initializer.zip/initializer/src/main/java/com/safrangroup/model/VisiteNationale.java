/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.Visite;
import java.time.LocalDateTime;
import java.util.List;
import javax.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@NoArgsConstructor
@Getter
@Setter
@Entity
@EqualsAndHashCode(callSuper = true)
@DiscriminatorColumn(name = "Visite_Nationale")
@Table(name = "VisiteNationale")
@SequenceGenerator(name = "default_gen", sequenceName = "visite_Nationale_seq", allocationSize = 1)
public class VisiteNationale extends Visite {

    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<VisiteurEcole> visiteurEcoles;
    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<VisiteurFormateur> visiteurFormateurs;
    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch = FetchType.LAZY)
    List<FournisseurNational> fournisseurNationals;

    public VisiteNationale(String intitule, String objectif, LocalDateTime dateVisite, Boolean restaurantPriseEnCharge, Boolean reunionCodir, Boolean cadeau, Boolean presentationSafran, List<Circuit> circuits, ValeursParametre societeJuridique, Utilisateur utilisateur,List<Object>visiteurs) {
        super(intitule, objectif, dateVisite, restaurantPriseEnCharge, reunionCodir, cadeau, presentationSafran, circuits, societeJuridique, utilisateur);
   if (visiteurs != null && !visiteurs.isEmpty()) {
            if (visiteurs.get(0) instanceof VisiteurEcole) {
                this.visiteurEcoles = (List<VisiteurEcole>) (Object) visiteurs;
            } else if (visiteurs.get(0) instanceof VisiteurFormateur) {
                this.visiteurFormateurs = (List<VisiteurFormateur>) (Object) visiteurs;
            } else if (visiteurs.get(0) instanceof FournisseurNational) {
                this.fournisseurNationals = (List<FournisseurNational>) (Object) visiteurs;
            }
        }
    }

     
}
