/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.safrangroup.model.inhertance.BaseEntity;
import javax.persistence.*;

/**
 *
 * @author Ala.Nabli
 */
@Entity
@Table(name = "utilisateur")
@SequenceGenerator(name = "default_gen", sequenceName = "utilisateur_seq", allocationSize = 1)
public class Utilisateur extends BaseEntity {

    private String nom;
    private String prenom;
    private String fonction;
    private String mail;
    private String login;
    @Column(name = "motDePasse")
    private String motDePasse;
    private Boolean actif;
    private String matricule;
    @Column(name = "isDefined")
    private Boolean isDefined;
    @ManyToOne
    @JoinColumn(name = "id_sup")
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Utilisateur superieur;
    @ManyToOne
    @JoinColumn(name = "ru")
    private ValeursParametre ru;
    @ManyToOne
    @JoinColumn(name = "societe")
    private ValeursParametre societe;
    private Integer type;
    
    @ManyToOne
    RoleGlobal roleGlobal;

    public Utilisateur() {
    }

    public Utilisateur(String nom, String prenom, String fonction, String mail, String login, String motDePasse, Boolean actif, String matricule, Integer type, RoleGlobal roleGlobal) {
        this.nom = nom;
        this.prenom = prenom;
        this.fonction = fonction;
        this.mail = mail;
        this.login = login;
        this.motDePasse = motDePasse;
        this.actif = actif;
        this.matricule = matricule;
        this.type = type;
        this.roleGlobal = roleGlobal;
        this.isDefined=true;
    }

    
    
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public Boolean getActif() {
        return actif;
    }

    public void setActif(Boolean actif) {
        this.actif = actif;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public Boolean getIsDefined() {
        return isDefined;
    }

    public void setIsDefined(Boolean isDefined) {
        this.isDefined = isDefined;
    }

    public Utilisateur getSuperieur() {
        return superieur;
    }

    public void setSuperieur(Utilisateur superieur) {
        this.superieur = superieur;
    }

    public ValeursParametre getRu() {
        return ru;
    }

    public void setRu(ValeursParametre ru) {
        this.ru = ru;
    }

    public ValeursParametre getSociete() {
        return societe;
    }

    public void setSociete(ValeursParametre societe) {
        this.societe = societe;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

 
    public RoleGlobal getRoleGlobal() {
        return roleGlobal;
    }

    public void setRoleGlobal(RoleGlobal roleGlobal) {
        this.roleGlobal = roleGlobal;
    }

}
