/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model;

import com.safrangroup.model.inhertance.BaseEntity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import lombok.Builder;

/**
 *
 * @author Ala.Nabli
 */
@Builder
@Entity
@SequenceGenerator(name = "default_gen", sequenceName = "role_global_seq", allocationSize = 1)
public class RoleGlobal extends BaseEntity {

    private String name;
    String code;

    public RoleGlobal() {
    }

    public RoleGlobal(String name, String code) {
        this.name = name;
        this.code = code;

    }

    @Column(nullable = false, unique = true)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(nullable = false, unique = true)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
