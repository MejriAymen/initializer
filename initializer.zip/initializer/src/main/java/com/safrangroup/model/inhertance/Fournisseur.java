/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.model.inhertance;

import com.safrangroup.model.SocieteExterne;
import java.time.LocalDateTime;
import javax.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@DiscriminatorColumn(name = "type_fournisseur", discriminatorType = DiscriminatorType.STRING)
@EqualsAndHashCode(callSuper = true)
public class Fournisseur extends Visiteur {

    String mail;

    public Fournisseur(String mail, String nom, String prenom, String fonction, String cin, String numTelephone, String numVisAVis, Integer dureeIntervention, String contactUrgence, String photo, LocalDateTime heuredeb, LocalDateTime heureFin, SocieteExterne societeExterne) {
        super(nom, prenom, fonction, cin, numTelephone, numVisAVis, dureeIntervention, contactUrgence, photo, heuredeb, heureFin, societeExterne);
        this.mail = mail;
    }

   
}
