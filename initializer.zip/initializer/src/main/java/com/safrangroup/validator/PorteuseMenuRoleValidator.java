/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.validator;

import com.safrangroup.model.PorteuseMenuRole;
import java.util.ArrayList;
import java.util.List;

/**
 * @author L258775
 */
public class PorteuseMenuRoleValidator {

    public static List<String> validateAdd(PorteuseMenuRole entity) {
        List<String> errors = new ArrayList<>();
        if (entity == null || entity.getRole() == null || entity.getMenu() == null) {
            errors.add("Veuillez vérifier les données rattahcer au Porteuse Rôle Menu.");
        }
        return errors;
    }

    public static List<String> validateUpdate(PorteuseMenuRole entity) {
        List<String> errors = new ArrayList<>();
        if (entity == null || entity.getId() == null) {
            errors.add("Veuillez vérifier les données rattahcer au Porteuse Rôle Menu.");
        }
        return errors;
    }
}
