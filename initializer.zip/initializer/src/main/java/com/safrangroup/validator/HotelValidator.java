/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.validator;

import com.safrangroup.model.Hotel;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author L258775
 */
public class HotelValidator {

    public static List<String> validate(Hotel hotel) {
        List<String> errors = new ArrayList<>();

        if (hotel == null || hotel.getLibelle() == null) {
            errors.add("Veuillez vérifier les données rattahcer au hotel.");
        }
        return errors;
    }

}
