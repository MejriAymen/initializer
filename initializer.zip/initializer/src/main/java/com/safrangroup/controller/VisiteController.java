/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller;

import com.safrangroup.DTO.VisiteFournisseurInternationalDto;
import com.safrangroup.DTO.VisiteFournisseurNationalDto;
import com.safrangroup.DTO.VisiteVisiteurAuditeurDto;
import com.safrangroup.DTO.VisiteVisiteurClientDto;
import com.safrangroup.DTO.VisiteVisiteurEcoleDto;
import com.safrangroup.DTO.VisiteVisiteurFormateurDto;
import com.safrangroup.DTO.VisiteVisiteurGroupeDto;
import com.safrangroup.DTO.VisiteVisiteurPrestataireDto;
import com.safrangroup.controller.api.VisiteApi;
import com.safrangroup.model.inhertance.Visite;
import com.safrangroup.service.interfaces.UserService;
import com.safrangroup.service.interfaces.VisiteService;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Ala.Nabli
 */
@RestController
public class VisiteController implements VisiteApi {

    @Autowired
    public VisiteService service;
    @Autowired
    public UserService userService;

    /*
    Visiteur International
     */
    @Override
    public ResponseEntity<VisiteVisiteurGroupeDto> saveVisiteVisiteurGroupe(VisiteVisiteurGroupeDto visite) {
        return new ResponseEntity(service.save(visite), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<VisiteVisiteurClientDto> saveVisiteVisiteurClient(VisiteVisiteurClientDto visite) {
        return new ResponseEntity(service.save(visite), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<VisiteVisiteurAuditeurDto> saveVisiteVisiteurAuditeur(VisiteVisiteurAuditeurDto visite) {
        return new ResponseEntity(service.save(visite), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<VisiteVisiteurPrestataireDto> saveVisiteVisiteurPrestataire(VisiteVisiteurPrestataireDto visite) {
        return new ResponseEntity(service.save(visite), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<VisiteFournisseurInternationalDto> saveVisiteVisiteurFournisseurInterNational(VisiteFournisseurInternationalDto visite) {
        return new ResponseEntity(service.save(visite), HttpStatus.OK);
    }

    /*
    Visiteur National
     */
    @Override
    public ResponseEntity<VisiteVisiteurEcoleDto> saveVisiteVisiteurEcole(VisiteVisiteurEcoleDto visite) {
        return new ResponseEntity(service.save(visite), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<VisiteVisiteurFormateurDto> saveVisiteVisiteurFormateur(VisiteVisiteurFormateurDto visite) {
        return new ResponseEntity(service.save(visite), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<VisiteFournisseurInternationalDto> saveVisiteVisiteurFournisseurNational(VisiteFournisseurNationalDto visite) {
        return new ResponseEntity(service.save(visite), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<Visite>> findByDate(Date d) {
        return new ResponseEntity(service.findByDate(d), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Integer> findMaxId() {
        return new ResponseEntity(service.idLastVisite(), HttpStatus.OK);
    }

     
}
