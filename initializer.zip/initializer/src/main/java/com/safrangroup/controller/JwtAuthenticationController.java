/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller;

import com.safrangroup.DTO.RegisterFormDataDTO;
import com.safrangroup.DTO.UserWithTokenDTO;
import com.safrangroup.config.JwtRequest;
import com.safrangroup.controller.api.JwtAuthenticationApi;
import com.safrangroup.model.Utilisateur;
import com.safrangroup.service.interfaces.JwtAuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Ala.Nabli
 */
@RestController
public class JwtAuthenticationController implements JwtAuthenticationApi {

    @Autowired
    public JwtAuthenticationService service;

    @Override
    public ResponseEntity<UserWithTokenDTO> createAuthenticationToken(JwtRequest authenticationRequest) {
        return service.createAuthenticationToken(authenticationRequest);
    }

    @Override
    public ResponseEntity<RegisterFormDataDTO> getRegisterData() {
        return new ResponseEntity(service.getRegisterData(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Utilisateur> saveUser(Utilisateur user) {
        return new ResponseEntity(service.saveUser(user), HttpStatus.OK);
    }

}
