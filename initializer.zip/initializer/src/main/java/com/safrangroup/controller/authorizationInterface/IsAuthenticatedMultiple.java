/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller.authorizationInterface;

import com.safrangroup.utils.constant.RoleConstants;
import static com.safrangroup.utils.constant.RoleConstants.PACK_URL;
import static com.safrangroup.utils.constant.RoleConstants.PARENTHESE;
import static com.safrangroup.utils.constant.RoleConstants.TLD;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import org.springframework.security.access.prepost.PreAuthorize;

/**
 * @author L60018794
 **/
@Retention(RetentionPolicy.RUNTIME)
@PreAuthorize(PACK_URL + RoleConstants.DIRECTEUR_GENERAL + TLD + PACK_URL + RoleConstants.CHARGER_DEPLACEMENT_PROFESSIONNEL + TLD + PACK_URL + RoleConstants.CHARGER_SURETE + TLD + PACK_URL + RoleConstants.CODIR + TLD + PACK_URL + RoleConstants.COMPTABLE + TLD + PACK_URL + RoleConstants.CONSULTANT + TLD + PACK_URL + RoleConstants.CORRESPONDANT_RESSOURCES_HUMAINES + TLD + PACK_URL + RoleConstants.CORRESPONDANT_RESTAURANT + TLD + PACK_URL + RoleConstants.CORRESPONDANT_SSE + TLD + PACK_URL + RoleConstants.DIRECTEUR_RESSOURCES_HUMAINES + TLD + PACK_URL + RoleConstants.FINANCE + TLD + PACK_URL + RoleConstants.RESPONSABLE_COMMUNICATION + PARENTHESE)
public @interface IsAuthenticatedMultiple {

}
