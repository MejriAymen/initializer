/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller;

import com.safrangroup.controller.api.PorteurseRoleMenuApi;
import com.safrangroup.dtos.PorteuseMenuRoleDto;
import com.safrangroup.dtos.ResponsePorteuseRoleMenuDTO;
import com.safrangroup.service.interfaces.PorteuseMenuRoleService;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L258775
 */
@RestController
public class PorteuseRoleMenuController implements PorteurseRoleMenuApi {

    @Autowired
    private PorteuseMenuRoleService service;

    @Override
    public ResponseEntity<List<ResponsePorteuseRoleMenuDTO>> findAll() {
        return new ResponseEntity<>(service.findAllPorteusesRolesMenus(null), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<ResponsePorteuseRoleMenuDTO>> findAllPorteusesRolesMenus(Optional<Long> id) {
        return new ResponseEntity<>(service.findAllPorteusesRolesMenus(id), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<PorteuseMenuRoleDto> update(PorteuseMenuRoleDto porteuseMenuRoleDto) {
        PorteuseMenuRoleDto response = PorteuseMenuRoleDto.fromEntity(service.update(PorteuseMenuRoleDto.fromDto(porteuseMenuRoleDto)));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
