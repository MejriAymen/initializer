/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller.api;

import com.safrangroup.DTO.HotelDto;
import com.safrangroup.config.SecurityParams;
import com.safrangroup.controller.authorizationInterface.IsAuthenticatedMultiple;
import static com.safrangroup.utils.constant.AppRootConstants.APP_ROOT_HOTEL;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
/**
 *
 * @author L60018794
 */
@Api(description = "Ce contrôleur offre un ensemble d'opérations pour les hotels, Ce contrôleur gère les hotels, les méthodes HTTP utilisées sont (GET, Podt, Put, DELETE).")
public interface HotelApi {

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @GetMapping(value = APP_ROOT_HOTEL + "/getAll", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'GET' permet de récupérer la liste de tous les hotels")
    public ResponseEntity<List<HotelDto>> findAll();

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @PostMapping(value = APP_ROOT_HOTEL + "/add", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'POST' permet d'ajouter un hotel ")
    public ResponseEntity<HotelDto> add(@RequestBody HotelDto company);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @PutMapping(value = APP_ROOT_HOTEL + "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'PUT' permet de modifier un hotel"
            + "Cet api est disponisble pour les utilisateurs de role 'ADMIN'")
    public ResponseEntity<HotelDto> update(@RequestBody HotelDto company);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @DeleteMapping(value = APP_ROOT_HOTEL + "/delete/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'DELETE' permet de Supprimer  un hotel ,Cet api est disponisble pour les utilisateurs de role 'ADMIN", notes = "delete")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "ok company deleted")
        ,@ApiResponse(code = 404, message = "Entité non trouvée")
        , @ApiResponse(code = 304, message = "Entité utilisée par autre table")})
    public ResponseEntity delete(@PathVariable("id") Integer id);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @GetMapping(value = APP_ROOT_HOTEL + "/getById/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'GET' permet de récupérer un hotel selon l'ID qui est une variable de chemin:@PathVariable"
            + "Cet api est disponisble pour les utilisateurs de role 'ADMIN'")
    public ResponseEntity<HotelDto> findById(@PathVariable Integer id);
}
