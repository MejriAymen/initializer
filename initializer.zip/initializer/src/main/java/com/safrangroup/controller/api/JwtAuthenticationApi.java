/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller.api;

import com.safrangroup.DTO.RegisterFormDataDTO;
import com.safrangroup.DTO.UserWithTokenDTO;
import com.safrangroup.config.JwtRequest;
import com.safrangroup.config.SecurityParams;
import com.safrangroup.model.Utilisateur;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 *
 * @author Ala.Nabli
 */
@Api(description = "Ce Contrôleur offre un ensemble d'opérations pour les voitures de location d'une demande, les methodes utliser sont (GET,POST)")
public interface JwtAuthenticationApi {

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping("/authenticate")
    @ApiOperation(value = "verifier les informations d'utilisateur et créer une token si valide.")
    public ResponseEntity<UserWithTokenDTO> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @GetMapping("/getRegisterData")
    @ApiOperation(value = "recuperer les informations a afficher dans la formulaire d'incription (Superieurs / societe / ru).")
    public ResponseEntity<RegisterFormDataDTO> getRegisterData();

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping("/register")
    @ApiOperation(value = "sauvegarder un utilisateur lors de l'iscription.")
    public ResponseEntity<Utilisateur> saveUser(@RequestBody Utilisateur user);

}
