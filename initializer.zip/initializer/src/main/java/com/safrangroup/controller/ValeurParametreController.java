/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller;

import com.safrangroup.controller.api.ValeurParametreApi;
import com.safrangroup.model.ValeursParametre;
import com.safrangroup.service.interfaces.ValeurParametreService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Ala.Nabli
 */
@RestController
public class ValeurParametreController implements ValeurParametreApi {

    @Autowired
    ValeurParametreService service;

    @Override
    public ResponseEntity<List<ValeursParametre>> getValeursParametreByIdParametre(Integer idParametre) {
        return new ResponseEntity(service.getValeursParametreByIdParametre(idParametre), HttpStatus.OK);
    }
}
