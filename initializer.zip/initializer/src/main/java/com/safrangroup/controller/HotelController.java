/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller;

import com.safrangroup.DTO.HotelDto;
import com.safrangroup.controller.api.HotelApi;
import com.safrangroup.service.interfaces.HotelService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L258775
 */
@RestController
public class HotelController implements HotelApi {

    @Autowired
    private HotelService hotelService;

    @Override
    public ResponseEntity<List<HotelDto>> findAll() {
        return new ResponseEntity<>(hotelService.findAll(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<HotelDto> add(HotelDto hotel) {
        return new ResponseEntity<>(hotelService.add(hotel), HttpStatus.OK);

    }

    @Override
    public ResponseEntity<HotelDto> update(HotelDto hotel) {
        return new ResponseEntity<>(hotelService.update(hotel), HttpStatus.OK);
    }

    @Override
    public ResponseEntity delete(Integer Id) {
        hotelService.delete(Id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<HotelDto> findById(Integer id) {
        return new ResponseEntity<>(hotelService.findById(id), HttpStatus.OK);
    }

}
