/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller.api;

import com.safrangroup.DTO.VisiteFournisseurInternationalDto;
import com.safrangroup.DTO.VisiteFournisseurNationalDto;
import com.safrangroup.DTO.VisiteVisiteurAuditeurDto;
import com.safrangroup.DTO.VisiteVisiteurClientDto;
import com.safrangroup.DTO.VisiteVisiteurEcoleDto;
import com.safrangroup.DTO.VisiteVisiteurFormateurDto;
import com.safrangroup.DTO.VisiteVisiteurGroupeDto;
import com.safrangroup.DTO.VisiteVisiteurPrestataireDto;
import com.safrangroup.config.SecurityParams;
import com.safrangroup.controller.authorizationInterface.IsAuthenticatedMultiple;
import com.safrangroup.model.inhertance.Visite;
import static com.safrangroup.utils.constant.AppRootConstants.APP_ROOT_VISITE;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author L258775
 */
@Api(description = "Ce Contrôleur offre un ensemble d'opérations pour les visites , les methodes utliser sont (GET,POST,PUT,DELETE)")
public interface VisiteApi {

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @PostMapping(APP_ROOT_VISITE + "/saveVisiteVisiteurGroupe")
    @ApiOperation(value = "Ajout nouvelle visite VisiteurGroupe .")
    public ResponseEntity<VisiteVisiteurGroupeDto> saveVisiteVisiteurGroupe(@RequestBody VisiteVisiteurGroupeDto visite);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping(APP_ROOT_VISITE + "/saveVisiteVisiteurFournisseurInterNational")
    @ApiOperation(value = "Ajout nouvelle visite visiteurs international.")
    public ResponseEntity<VisiteFournisseurInternationalDto> saveVisiteVisiteurFournisseurInterNational(@RequestBody VisiteFournisseurInternationalDto visite);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping(APP_ROOT_VISITE + "/saveVisiteVisiteurFournisseurNational")
    @ApiOperation(value = "Ajout nouvelle visite visiteur national.")
    public ResponseEntity<VisiteFournisseurInternationalDto> saveVisiteVisiteurFournisseurNational(@RequestBody VisiteFournisseurNationalDto visite);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping(APP_ROOT_VISITE + "/saveVisiteVisiteurClient")
    @ApiOperation(value = "Ajout nouvelle visite visiteur client international.")
    public ResponseEntity<VisiteVisiteurClientDto> saveVisiteVisiteurClient(@RequestBody VisiteVisiteurClientDto visite);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping(APP_ROOT_VISITE + "/saveVisiteVisiteurAuditeur")
    @ApiOperation(value = "Ajout nouvelle visite visiteur auditeur international.")
    public ResponseEntity<VisiteVisiteurAuditeurDto> saveVisiteVisiteurAuditeur(@RequestBody VisiteVisiteurAuditeurDto visite);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping(APP_ROOT_VISITE + "/saveVisiteVisiteurPrestataire")
    @ApiOperation(value = "Ajout nouvelle visite visiteur prestataire international.")
    public ResponseEntity<VisiteVisiteurPrestataireDto> saveVisiteVisiteurPrestataire(@RequestBody VisiteVisiteurPrestataireDto visite);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping(APP_ROOT_VISITE + "/saveVisiteVisiteurEcole")
    @ApiOperation(value = "Ajout nouvelle visite visiteur école nationale.")
    public ResponseEntity<VisiteVisiteurEcoleDto> saveVisiteVisiteurEcole(@RequestBody VisiteVisiteurEcoleDto visite);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @PostMapping(APP_ROOT_VISITE + "/saveVisiteVisiteurFormateur")
    @ApiOperation(value = "Ajout nouvelle visite visiteur formateur national.")
    public ResponseEntity<VisiteVisiteurFormateurDto> saveVisiteVisiteurFormateur(@RequestBody VisiteVisiteurFormateurDto visite);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @GetMapping(APP_ROOT_VISITE + "/findByDate")
    @ApiOperation(value = "recuperer la liste des visites par date .")
    public ResponseEntity<List<Visite>> findByDate(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date date);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @GetMapping(APP_ROOT_VISITE + "/findMaxId")
    @ApiOperation(value = "recuperer le numéro du dérnière visite a ajouté .")
    public ResponseEntity<Integer> findMaxId();

}
