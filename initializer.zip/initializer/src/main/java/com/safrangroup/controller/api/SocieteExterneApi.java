/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller.api;

import com.safrangroup.config.SecurityParams;
import com.safrangroup.controller.authorizationInterface.IsAuthenticatedMultiple;
import com.safrangroup.model.SocieteExterne;
import static com.safrangroup.utils.constant.AppRootConstants.APP_ROOT_SOCIETE_EXTERNE;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 *
 * @author L60018794
 */
@Api(description = "Ce contrôleur offre un ensemble d'opérations pour les hotels, Ce contrôleur gère les hotels, les méthodes HTTP utilisées sont (GET, Podt, Put, DELETE).")
public interface SocieteExterneApi {

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @GetMapping(value = APP_ROOT_SOCIETE_EXTERNE + "/getAll", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'GET' permet de récupérer la liste de tous les hotels")
    public ResponseEntity<List<SocieteExterne>> findAll();

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @PostMapping(value = APP_ROOT_SOCIETE_EXTERNE + "/add", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'POST' permet d'ajouter une socité externe ")
    public ResponseEntity<SocieteExterne> add(@RequestBody SocieteExterne company);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @PutMapping(value = APP_ROOT_SOCIETE_EXTERNE + "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'PUT' permet de modifier une socité externe"
            + "Cet api est disponisble pour les utilisateurs de role 'ADMIN'")
    public ResponseEntity<SocieteExterne> update(@RequestBody SocieteExterne company);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @DeleteMapping(value = APP_ROOT_SOCIETE_EXTERNE + "/delete/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'DELETE' permet de Supprimer  une socité externe ,Cet api est disponisble pour les utilisateurs de role 'ADMIN", notes = "delete")
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "ok company deleted")
        ,@ApiResponse(code = 404, message = "Entité non trouvée")
        , @ApiResponse(code = 304, message = "Entité utilisée par autre table")})
    public ResponseEntity delete(@PathVariable("id") Integer id);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @GetMapping(value = APP_ROOT_SOCIETE_EXTERNE + "/getById/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'GET' permet de récupérer une socité externe selon l'ID qui est une variable de chemin:@PathVariable"
            + "Cet api est disponisble pour les utilisateurs de role 'ADMIN'")
    public ResponseEntity<SocieteExterne> findById(@PathVariable Integer id);
}
