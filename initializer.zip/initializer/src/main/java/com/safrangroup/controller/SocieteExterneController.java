/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller;

import com.safrangroup.controller.api.SocieteExterneApi;
import com.safrangroup.model.SocieteExterne;
import com.safrangroup.service.interfaces.SocieteExterneService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author L258775
 */
@RestController
public class SocieteExterneController implements SocieteExterneApi {

    @Autowired
    private SocieteExterneService societeExterneService;

    @Override
    public ResponseEntity<List<SocieteExterne>> findAll() {
        return new ResponseEntity<>(societeExterneService.findAll(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SocieteExterne> add(SocieteExterne hotel) {
        return new ResponseEntity<>(societeExterneService.add(hotel), HttpStatus.OK);

    }

    @Override
    public ResponseEntity<SocieteExterne> update(SocieteExterne hotel) {
        return new ResponseEntity<>(societeExterneService.update(hotel), HttpStatus.OK);
    }

    @Override
    public ResponseEntity delete(Integer Id) {
        societeExterneService.delete(Id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SocieteExterne> findById(Integer id) {
        return new ResponseEntity<>(societeExterneService.findById(id), HttpStatus.OK);
    }

}
