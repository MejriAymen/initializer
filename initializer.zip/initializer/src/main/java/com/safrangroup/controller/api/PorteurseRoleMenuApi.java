/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.controller.api;

import com.safrangroup.config.SecurityParams;
import com.safrangroup.controller.authorizationInterface.IsAuthenticatedMultiple;
import com.safrangroup.dtos.PorteuseMenuRoleDto;
import com.safrangroup.dtos.ResponsePorteuseRoleMenuDTO;
import static com.safrangroup.utils.constant.AppRootConstants.APP_ROOT_PORTEUSE_ROLE_MENU;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import java.util.Optional;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 *
 * @author L60018794
 */
@Api(description = "Ce contrôleur Porteuse entre menus et rôles")
public interface PorteurseRoleMenuApi {

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @GetMapping(value = APP_ROOT_PORTEUSE_ROLE_MENU + "/getAll", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'GET' permet de récupérer la liste de tous les rôles par menu")
    public ResponseEntity<List<ResponsePorteuseRoleMenuDTO>> findAll();

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @PutMapping(value = APP_ROOT_PORTEUSE_ROLE_MENU + "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'PUT' permet de modifier les accès"
            + "Cet api est disponisble pour les utilisateurs de role 'ADMIN'")
    public ResponseEntity<PorteuseMenuRoleDto> update(@RequestBody PorteuseMenuRoleDto porteuseMenuRoleDto);

    @CrossOrigin(origins = SecurityParams.FRONT_CROSS_ORIGIN_URL)
    @IsAuthenticatedMultiple
    @GetMapping(value = APP_ROOT_PORTEUSE_ROLE_MENU + "/findAllPorteusesRolesMenus/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Api 'GET' permet de récupérer tous les rôle ainsi que leurs menus")
    public ResponseEntity<List<ResponsePorteuseRoleMenuDTO>> findAllPorteusesRolesMenus(@PathVariable(required = true) Optional<Long> id);

}
