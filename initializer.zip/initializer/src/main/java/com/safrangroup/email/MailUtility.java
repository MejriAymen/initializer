/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.email;

import com.safrangroup.exception.exceptiongeneric.MessagingExceptionCatcher;
import com.safrangroup.exception.handler.ErrorCodes;
import com.safrangroup.utils.constant.MailConstants;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Ala.Nabli
 */
public class MailUtility {

    private static final String USERNAME = "initializer@safrangroup.com";

    private static final String PASSWORD = "";

    public static void sendEmail(String toAddress, String subject, String message) throws AddressException, MessagingException {
        // sets SMTP server properties
        // sets SMTP server properties
        Properties properties = new Properties();
        properties.put(MailConstants.MAIL_HOST, MailConstants.HOST);
        properties.put(MailConstants.MAIL_PORT, MailConstants.PORT);
        properties.put(MailConstants.MAIL_AUTH, MailConstants.AUTH);
        properties.put(MailConstants.MAIL_STARTTLS, MailConstants.STARTTLS);
        // creates a new session with an authenticator
        Authenticator auth = new Authenticator() {
            @Override
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, PASSWORD);
            }
        };
        Session session = Session.getInstance(properties, auth);
        // creates a new e-mail message
        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(USERNAME));
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toAddress));
        msg.setSubject(subject);
        msg.setSentDate(new Date());
        msg.setText(message);
        // sends the e-mail
        Transport.send(msg);
    }

    public static void sendEmail(List<String> toAddress, String subject, String message, List<String> ccAdress) throws AddressException, MessagingException {
        // sets SMTP server properties
        Properties properties = new Properties();
        properties.put(MailConstants.MAIL_HOST, MailConstants.HOST);
        properties.put(MailConstants.MAIL_PORT, MailConstants.PORT);
        properties.put(MailConstants.MAIL_AUTH, MailConstants.AUTH);
        properties.put(MailConstants.MAIL_STARTTLS, MailConstants.STARTTLS);
        // creates a new session with an authenticator
        Authenticator auth = new Authenticator() {
            @Override
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, PASSWORD);
            }
        };
        Session session = Session.getInstance(properties, auth);
        // creates a new e-mail message
        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(USERNAME));
        for (String to : toAddress) {
            msg.addRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        }
        for (String cc : ccAdress) {
            msg.addRecipients(Message.RecipientType.CC, InternetAddress.parse(cc));
        }

        msg.setSubject(subject);
        msg.setSentDate(new Date());
        msg.setText(message);

        // sends the e-mail
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                Transport.send(msg);
                executor.shutdown();
            } catch (MessagingException ex) {
                throw new MessagingExceptionCatcher(ErrorCodes.MESSAGING_EXCEPTION);
            }
        });
    }
}
