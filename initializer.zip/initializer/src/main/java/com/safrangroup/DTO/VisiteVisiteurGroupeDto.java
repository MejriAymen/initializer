/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import com.safrangroup.model.Circuit;
import com.safrangroup.model.VisiteInternationale;
import com.safrangroup.model.VisiteurGroupe;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@NoArgsConstructor
@Getter
@Setter
public class VisiteVisiteurGroupeDto extends VisiteInternationaleDto {

    List<VisiteurGroupe> visiteurGroupes;

    public VisiteVisiteurGroupeDto(List<VisiteurGroupe> visiteurGroupes, String numeroVolAller, String numeroVolRetour, LocalDateTime dateArriveEnTunisie, LocalDateTime dateArriveeSurSite, LocalDateTime dateDeparTunisie, Boolean sejourPriseEnCharge, Boolean netCarPriseEnCharge, HotelDto hotelDto, Integer nbrJrsReservationHotel, Integer id, String intitule, String objectif, LocalDateTime dateVisite, Boolean restaurantPriseEnCharge, Boolean reunionCodir, Boolean cadeau, Boolean presentationSafran, List<CircuitDto> circuitDtos, SocieteJuridiqueDto societeJuridiqueDto, UtilisateurDto utilisateurDto) {
        super(numeroVolAller, numeroVolRetour, dateArriveEnTunisie, dateArriveeSurSite, dateDeparTunisie, sejourPriseEnCharge, netCarPriseEnCharge, hotelDto, nbrJrsReservationHotel, id, intitule, objectif, dateVisite, restaurantPriseEnCharge, reunionCodir, cadeau, presentationSafran, circuitDtos, societeJuridiqueDto, utilisateurDto);
        this.visiteurGroupes = visiteurGroupes;
    }

    public static VisiteInternationale fromDto(VisiteVisiteurGroupeDto visite) {
        List<Circuit> circuits = new ArrayList<>();
        visite.getCircuitDtos().forEach(c -> {
            circuits.add(CircuitDto.fromDto(c));
        });
        VisiteInternationale v = new VisiteInternationale(visite.getNumeroVolAller(), visite.getNumeroVolRetour(), visite.getDateArriveEnTunisie(), visite.getDateArriveeSurSite(), visite.getDateDeparTunisie(), visite.getSejourPriseEnCharge(), visite.getNetCarPriseEnCharge(), HotelDto.fromDto(visite.getHotelDto()), visite.getNbrJrsReservationHotel(), visite.getIntitule(), visite.getObjectif(), visite.getDateVisite(), visite.getRestaurantPriseEnCharge(), visite.getReunionCodir(), visite.getCadeau(), visite.getPresentationSafran(), circuits, SocieteJuridiqueDto.fromDto(visite.getSocieteJuridiqueDto()), UtilisateurDto.fromDto(visite.getUtilisateurDto()), (List) visite.getVisiteurGroupes());
        if (visite.getId() != null) {
            v.setId(visite.getId());
        }
        return v;
    }

    public static VisiteVisiteurGroupeDto toDto(VisiteInternationale visite) {
   List<CircuitDto> circuitDtos = new ArrayList<>();
        visite.getCircuits().forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        VisiteVisiteurGroupeDto dto = new VisiteVisiteurGroupeDto(visite.getVisiteurGroupes(),visite.getNumeroVolAller(), visite.getNumeroVolRetour(),visite.getDateArriveEnTunisie(),visite.getDateArriveeSurSite(),visite.getDateDeparTunisie(), visite.getSejourPriseEnCharge(),visite.getNetCarPriseEnCharge(),HotelDto.toDto(visite.getHotel()), visite.getNbrJrsReservationHotel(), visite.getId(), visite.getIntitule(), visite.getObjectif(),visite.getDateVisite(),visite.getRestaurantPriseEnCharge(),visite.getReunionCodir(), visite.getCadeau(),visite.getPresentationSafran(), circuitDtos, SocieteJuridiqueDto.toDto(visite.getSocieteJuridique()), UtilisateurDto.toDto(visite.getUtilisateur()));
        return dto;
    }

}
