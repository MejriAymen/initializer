/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import com.safrangroup.model.Circuit;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CircuitDto implements Comparable<CircuitDto> {

    Integer id;
    private LocalDateTime heureDebut;
    private LocalDateTime heureFin;
    Integer duree;
    Integer priorite;
    SocieteJuridiqueDto ruDto;

    @Override
    public int compareTo(CircuitDto o) {
        return this.priorite - o.getPriorite();
    }

    public static Circuit fromDto(CircuitDto circuitDto) {
        Circuit c = new Circuit(circuitDto.getHeureDebut(), circuitDto.getHeureFin(), circuitDto.getDuree(), circuitDto.getPriorite(),SocieteJuridiqueDto.fromDto(circuitDto.getRuDto()));
        if (circuitDto.getId() != null) {
            c.setId(circuitDto.getId());
        }
        return c;
    }

    public static CircuitDto toDto(Circuit circuit) {
        CircuitDto dto = new CircuitDto(circuit.getId(), circuit.getHeureDebut(), circuit.getHeureFin(), circuit.getDuree(), circuit.getPriorite(),SocieteJuridiqueDto.toDto(circuit.getValeursParametre()));
        return dto;
    }

}
