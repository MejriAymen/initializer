/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import com.safrangroup.model.Utilisateur;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@NoArgsConstructor
@Getter
@Setter
public class UtilisateurDto {

    Integer id;

    public UtilisateurDto(Integer id) {
        this.id = id;
    }

    public static Utilisateur fromDto(UtilisateurDto utilisateurDto) {
        Utilisateur u = new Utilisateur();
        if (utilisateurDto.getId() != null) {
            u.setId(utilisateurDto.getId());
        }
        return u;
    }

    public static UtilisateurDto toDto(Utilisateur utilisateur) {
        UtilisateurDto dto = new UtilisateurDto(utilisateur.getId());
        return dto;
    }

}
