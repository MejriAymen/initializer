/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import com.safrangroup.model.Circuit;
import com.safrangroup.model.VisiteNationale;
import com.safrangroup.model.VisiteurEcole;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@NoArgsConstructor
@Getter
@Setter
public class VisiteVisiteurEcoleDto extends VisiteVisiteurNationalDto {

    List<VisiteurEcole> visiteurEcoles;

    public VisiteVisiteurEcoleDto(List<VisiteurEcole> visiteurEcoles, Integer id, String intitule, String objectif, LocalDateTime dateVisite, Boolean restaurantPriseEnCharge, Boolean reunionCodir, Boolean cadeau, Boolean presentationSafran, List<CircuitDto> circuitDtos, SocieteJuridiqueDto societeJuridiqueDto, UtilisateurDto utilisateurDto) {
        super(id, intitule, objectif, dateVisite, restaurantPriseEnCharge, reunionCodir, cadeau, presentationSafran, circuitDtos, societeJuridiqueDto, utilisateurDto);
        this.visiteurEcoles = visiteurEcoles;
    }

       public static VisiteNationale fromDto(VisiteVisiteurEcoleDto visite) {
        List<Circuit> circuits = new ArrayList<>();
        visite.getCircuitDtos().forEach(c -> {
            circuits.add(CircuitDto.fromDto(c));
        });
        VisiteNationale v = new VisiteNationale("intitule", "objectif", LocalDateTime.now(), Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, Boolean.TRUE, circuits,SocieteJuridiqueDto.fromDto(visite.getSocieteJuridiqueDto()), UtilisateurDto.fromDto(visite.getUtilisateurDto()), (List)  visite.getVisiteurEcoles());
        if (visite.getId() != null) {
            v.setId(visite.getId());
        }
        return v;
    }

    public static VisiteVisiteurEcoleDto toDto(VisiteNationale visite) {
   List<CircuitDto> circuitDtos = new ArrayList<>();
        visite.getCircuits().forEach(c -> {
            circuitDtos.add(CircuitDto.toDto(c));
        });
        VisiteVisiteurEcoleDto dto = new VisiteVisiteurEcoleDto(visite.getVisiteurEcoles(), visite.getId(), visite.getIntitule(),visite.getObjectif(), visite.getDateVisite(),visite.getRestaurantPriseEnCharge(), visite.getReunionCodir(),visite.getCadeau(),visite.getPresentationSafran(),circuitDtos, SocieteJuridiqueDto.toDto(visite.getSocieteJuridique()), UtilisateurDto.toDto(visite.getUtilisateur()));
        return dto;
    }   
}
