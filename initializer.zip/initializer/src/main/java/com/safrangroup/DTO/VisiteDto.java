/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Ala.Nabli
 */

@NoArgsConstructor
@Getter
@Setter
public class VisiteDto {

    Integer id;
    String intitule;
    String objectif;
    LocalDateTime dateVisite;
    Boolean restaurantPriseEnCharge;
    Boolean reunionCodir;
    Boolean cadeau;
    Boolean presentationSafran;

    List<CircuitDto> circuitDtos;
    SocieteJuridiqueDto societeJuridiqueDto;
    UtilisateurDto utilisateurDto;

    public VisiteDto(Integer id, String intitule, String objectif, LocalDateTime dateVisite, Boolean restaurantPriseEnCharge, Boolean reunionCodir, Boolean cadeau, Boolean presentationSafran, List<CircuitDto> circuitDtos, SocieteJuridiqueDto societeJuridiqueDto, UtilisateurDto utilisateurDto) {
        this.id = id;
        this.intitule = intitule;
        this.objectif = objectif;
        this.dateVisite = dateVisite;
        this.restaurantPriseEnCharge = restaurantPriseEnCharge;
        this.reunionCodir = reunionCodir;
        this.cadeau = cadeau;
        this.presentationSafran = presentationSafran;
        this.circuitDtos = circuitDtos;
        this.societeJuridiqueDto = societeJuridiqueDto;
        this.utilisateurDto = utilisateurDto;
    }

    

}
