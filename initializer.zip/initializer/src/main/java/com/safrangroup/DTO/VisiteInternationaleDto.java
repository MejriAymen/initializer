/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@NoArgsConstructor
@Getter
@Setter
 public class VisiteInternationaleDto extends VisiteDto {

    String numeroVolAller;
    String numeroVolRetour;
    LocalDateTime dateArriveEnTunisie;
    LocalDateTime dateArriveeSurSite;
    LocalDateTime dateDeparTunisie;
    Boolean sejourPriseEnCharge;
    Boolean netCarPriseEnCharge;
     HotelDto hotelDto;
    Integer nbrJrsReservationHotel;

    public VisiteInternationaleDto(String numeroVolAller, String numeroVolRetour, LocalDateTime dateArriveEnTunisie, LocalDateTime dateArriveeSurSite, LocalDateTime dateDeparTunisie, Boolean sejourPriseEnCharge, Boolean netCarPriseEnCharge, HotelDto hotelDto, Integer nbrJrsReservationHotel, Integer id, String intitule, String objectif, LocalDateTime dateVisite, Boolean restaurantPriseEnCharge, Boolean reunionCodir, Boolean cadeau, Boolean presentationSafran, List<CircuitDto> circuitDtos, SocieteJuridiqueDto societeJuridiqueDto, UtilisateurDto utilisateurDto) {
        super(id, intitule, objectif, dateVisite, restaurantPriseEnCharge, reunionCodir, cadeau, presentationSafran, circuitDtos, societeJuridiqueDto, utilisateurDto);
        this.numeroVolAller = numeroVolAller;
        this.numeroVolRetour = numeroVolRetour;
        this.dateArriveEnTunisie = dateArriveEnTunisie;
        this.dateArriveeSurSite = dateArriveeSurSite;
        this.dateDeparTunisie = dateDeparTunisie;
        this.sejourPriseEnCharge = sejourPriseEnCharge;
        this.netCarPriseEnCharge = netCarPriseEnCharge;
        this.hotelDto = hotelDto;
        this.nbrJrsReservationHotel = nbrJrsReservationHotel;
    }

   

}
