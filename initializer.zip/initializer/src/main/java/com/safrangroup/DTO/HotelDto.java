/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import com.safrangroup.model.Hotel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Ala.Nabli
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class HotelDto {

    Integer id;
    String libelle;
    String info;
    String tel;
    Boolean visible;

    public HotelDto(String libelle) {
        this.libelle = libelle;
    }

    public static Hotel fromDto(HotelDto hotelDto) {
        Hotel c = new Hotel(hotelDto.getLibelle(), hotelDto.getInfo(), hotelDto.getTel(), hotelDto.getVisible());
        if (hotelDto.getId() != null) {
            c.setId(hotelDto.getId());
        }
        return c;
    }

    public static HotelDto toDto(Hotel hotel) {
        HotelDto dto = new HotelDto(hotel.getId(), hotel.getLibelle(), hotel.getInfo(), hotel.getTel(), hotel.getVisible());
        return dto;
    }

}
