/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import com.safrangroup.model.ValeursParametre;
import java.util.List;

/**
 *
 * @author Ala.Nabli
 */
public class RegisterFormDataDTO {

    private List<RegisterFormUserDTO> users;
    private List<ValeursParametre> societe;
    private List<ValeursParametre> ru;

    public RegisterFormDataDTO() {
    }

    public RegisterFormDataDTO(List<RegisterFormUserDTO> users, List<ValeursParametre> societe, List<ValeursParametre> ru) {
        this.users = users;
        this.societe = societe;
        this.ru = ru;
    }

    public List<RegisterFormUserDTO> getUsers() {
        return users;
    }

    public void setUsers(List<RegisterFormUserDTO> users) {
        this.users = users;
    }

    public List<ValeursParametre> getSociete() {
        return societe;
    }

    public void setSociete(List<ValeursParametre> societe) {
        this.societe = societe;
    }

    public List<ValeursParametre> getRu() {
        return ru;
    }

    public void setRu(List<ValeursParametre> ru) {
        this.ru = ru;
    }
}
