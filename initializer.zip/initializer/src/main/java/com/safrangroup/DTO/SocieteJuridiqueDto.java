/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.safrangroup.DTO;

import com.safrangroup.model.ValeursParametre;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Ala.Nabli
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SocieteJuridiqueDto {

    Integer id;
    private String valeurParametre;
    private Integer ordre;
    private Boolean actif;

   public static ValeursParametre fromDto(SocieteJuridiqueDto societeDto) {
        ValeursParametre c = new ValeursParametre(societeDto.getValeurParametre(), societeDto.getOrdre(), societeDto.getActif());
        if (societeDto.getId() != null) {
            c.setId(societeDto.getId());
        }
        return c;
    }

    public static SocieteJuridiqueDto toDto(ValeursParametre societe) {
        SocieteJuridiqueDto dto = new SocieteJuridiqueDto(societe.getId(),societe.getValeurParametre(), societe.getOrdre(), societe.getActif());
        return dto;
    }
}
